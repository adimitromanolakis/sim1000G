familyDesign2 <-
function(n=1000, depend=1, affectnum=0,
		  base.dist="Weibull", frailty.dist="gamma", 
          vbeta= c(-1.126, 2.55, 1.6), parms=c(0.016, 3), age1=c(65,2.5), age2=c(45,2.5), 
          agemin=20, data, genotype, corr_type = "frailty", IBD_matrix = NULL, alpha= NULL, gu = NULL, nongen_cov = NULL) 
{
data.new<-numeric()
cumind<-0
i<- 1
j<- 0


if(is.null(genotype)){genotype_yes <- FALSE

pedigree <- data.frame(famID = data$famID, indID = data$ID, fatherID = data$fatherID, motherID = data$motherID, gender = data$gender, 
                       status = rep(0, dim(data)[1]), generation = data$generation)
}else{genotype_yes <- TRUE

pedigree <- data.frame(famID = data$famID, indID = data$ID, fatherID = data$fatherID, motherID = data$motherID, gender = data$gender, 
                       status = rep(0, dim(data)[1]), generation = data$generation, genotype)
}

#pedigreeFam <- data.frame(famID = data$famID, indID = data$ID,, fatherID = data$fatherID, motherID = data$motherID, gender = data$gender, 
 #                         status = rep(0, dim(data)[1]), genotype)

while (i <= n) {
  pedigreeFam <- pedigree[pedigree$famID == i,]
  j <- j + 1
   dat<-try(familyStructure2(i,cumind=cumind, 
  		base.dist=base.dist, frailty.dist=frailty.dist,
	    depend=depend, parms=parms, vbeta=vbeta,  age1=age1, age2=age2,
	    agemin=agemin, pedigree = pedigreeFam, corr_type = corr_type, IBD = IBD_matrix[pedigree$famID == i, pedigree$famID == i], alpha = alpha[i,], gu = gu[i,],
  		nongen_cov = nongen_cov, genotype_yes))
 	#    pedigree <- dat[[2]]
  dat <- dat[[1]]
 # if(is.null(attr(dat, "class"))){
	   # At least one parent in first gen and two sibs in the second gen should be affected
#	if(affectnum==3) until<- ifelse(sum(dat[dat[,7]==1,13]) >= 1 & sum(dat[dat[,7]==2,13]) > 1, TRUE, FALSE) 
	#[,7]=generation, [,13]=status
    # Proband must be affected
   	if(affectnum==1) until <- ifelse(sum(dat[dat[,6]==1,11]) == 1, TRUE, FALSE)
    #[,7]=generation, [,11]=status [,6]=proband
	else
    until <- TRUE

		if(!is.null(dim(dat))){
	    if(nrow(dat)>0 ){
	    	if(until){
		   	    data.new<-rbind(data.new, dat)
        		cumind<-cumind+nrow(dat)
        		i<-i+1
	   		}    
		  }
		}


#} # close "is.null(attr(dat, "class"))"
} # close while

data.new
}
