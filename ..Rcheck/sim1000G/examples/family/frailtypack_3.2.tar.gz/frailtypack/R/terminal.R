
"terminal"<-function(x)
 {
  x
 }
