
#!------------------------------------------------------------
#  !                   MARQ98
#!-------------------------------------------------------------
  
  
marq98j <- function(k0,b,m,ni,v,rl,ier,istop,effet,ca,cb,dd,fctnames,nva,
                    model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                    m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                    mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                    nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                  ndatemax,memb,Kmat){
#  !  fu  <-  matrice des derivees secondes et premieres

#  !  istop: raison de larret
#!  1: critere darret satisfait (prm <- ca, vraisblce <- cb, derivee <- dd)
#!  2: nb max diterations atteints
#!  4: Erreur
  b <- b[1:m]
  zero <- rep(0, 2)
  fu <- rep(0, m*(m+3)/2)
  v1 <- rep(0, m*(m+3)/2)
  vnonpen <- rep(0, m*(m+3)/2)
  delta <- rep(0, m)
  b1 <- rep(0, m)
  bh <- rep(0, m)
vvv <- 0
  zero <- 0
  id <- 0
  jd <- 0
  z <- 0
  th <- 1e-5
  eps <- 1e-7
  nfmax <- m*(m+1)/2
  ca <- epsa+1
  cb <- epsb+1
  rl1 <- -1e+10
  ni <- 0
  istop <- 0
  da <- 0.01
  dm <- 5
  nql <- 1
  m1 <- m*(m+1)/2
  ep <- 1e-20
  #Main:Do       
repeat{
  derivaJ_list <- derivaJ(b,m,v,rl,k0,fctnames, model,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
               mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
               nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,np,
               ndatemax,memb,Kmat)  

  v <- derivaJ_list[[1]]
  rl <- derivaJ_list[[2]]
  pe <- derivaJ_list[[3]]
  resnonpen <- derivaJ_list[[4]]
  rl1 <- rl

  if(rl == -1e+9){
    istop <- 4
    #marq98j_list <- list(b,v,rl,ier,istop,I_hess,H_hess,hess,vvv,epsa,epsb,epsd)
    break
  }
print(paste("iteration***",ni,"vrais",rl))

#print(paste("iteration ***", ni,"vecteur b ", b))
#write(*,*) m, m, iun, iun, z, z, k0, k0

  dd  <-  0
  fu  <-  0
  for(i in 1:m){
    for(j in i:m){
      ij <- (j-1)*j/2+i
      fu[ij] <- v[ij]
    }
  }

  dsinvj_list <- dsinvj(fu,m,ep,ier)
  fu <- dsinvj_list[[1]]
  ier <- dsinvj_list[[2]]

#  print(fu)
#  print(ier)
  if(ier == -1){ #then ! hessienne non inversible
    dd <- epsd+1
  }else{
    GHG  <-  0
    for(i in 1:m){
      for(j in 1:m){
        if(j >= i){
          ij <- (j-1)*j/2+i
        }else{
          ij <- (i-1)*i/2+j
        }
        GHG  <-  GHG + v[m1+i]*fu[ij]*v[m1+j]
      }
    }
    dd <- GHG/m
  }
    
#if(ni == 10)break
print(paste('epsa',ca,'epsb',cb,'epsd',dd))
#  print(b)

#   write(*,*)aaOptim: b(knots),b(1:12)
# write(*,*) aaOptim: m,m, nva, nva1, nva2
#!! write(*,*)aaOptim: b(random):, b((m-nva-3):(m-nva))
#!write(*,*)aaOptim: b(covar),b((m-nva+1):m)

#     print*,ca,cb,dd
#     print*,b
#    print*,"-------------------------"

  if(ca >= epsa || cb >= epsb || dd >= epsd){

    tr <- 0
    for(i in 1:m){
      ii <- i*(i+1)/2
      tr<- tr+abs(v[ii])
    }
    tr <- tr/m
    ncount <- 0
    ga <- 0.01
    idpos <- 1
    while(idpos != 0){
      for(i in 1:(nfmax+m)){
        fu[i] <- v[i]
      }

      for(i in 1:m){
        ii <- i*(i+1)/2
        if(v[ii] != 0){
          fu[ii] <- v[ii]+da*((1-ga)*abs(v[ii])+ga*tr)
        }else{
          fu[ii] <- da*ga*tr
        }
      }
      
      dcholej_list <- dcholej(fu,m,nql,idpos)
      fu <- dcholej_list[[1]]
      idpos <- dcholej_list[[2]]
   
      if(idpos != 0){
        ncount <- ncount+1
        if(ncount <= 3 || ga >= 1){
          da <- da*dm
        }else{
          ga <- ga*dm
          if(ga > 1)ga <- 1
        }
      }
    }
    for(i in 1:m){
      delta[i] <- fu[nfmax+i]
      b1[i] <- b[i]+delta[i]
    }
    rl_list <- fctnames(b1,m,id,z,jd,z,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                   mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                   nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                   ndatemax,memb,Kmat)
  rl <- rl_list[[1]]
  pe <- rl_list[[2]]
  
  resnonpen <- rl_list[[3]]
    if(rl == -1e+9){
      istop <- 4
        #goto 110
      break
    }
  
    if(rl1 < rl){
      if(da < eps){
        da <- eps
      }else{
        da <- da/(dm+2)
      }
      #    goto 800
      cb <- abs(rl1-rl)
      
      ca <- 0
      for(i in 1:m){
        ca <- ca+delta[i]*delta[i]
      }
      for(i in 1:m){
        b[i] <- b[i]+delta[i]
      }
      
      ni <- ni+1
   
      if(ni >= maxiter){
        istop <- 2
#      !            write(6,*) maximum number of iteration reached
 #     goto 110
        break
      }
    }
    if(rl1 >= rl){
      maxt <- 0
      maxt <- dmaxt(maxt,delta,m)
      if(maxt == 0){
        vw <- th
      }else{
        vw <- th/maxt
      }  
    
    
    step <- log(1.5)
    fi <- 0
    vw_list <- searpasj(vw,step,b,bh,m,delta,fi,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                   mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                   nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                   ndatemax,memb,Kmat)
    vw <- vw_list[[1]]
    pe <- vw_list[[2]]
    resnonpen <- vw_list[[3]]
        rl <- -fi
    if(rl == -1e+9){
      istop <- 4
  #  goto 110
      break
    }
    for(i in 1:m){
      delta[i] <- vw*delta[i]
    }
    da <- (dm-3)*da
    
    cb <- abs(rl1-rl)
    
    ca <- 0
    for(i in 1:m){
      ca <- ca+delta[i]*delta[i]
    }
    
    for(i in 1:m){
      b[i] <- b[i]+delta[i]
    }
    
    ni <- ni+1
    if(ni >= maxiter){
      istop <- 2
  #  !            write(6,*) maximum number of iteration reached
   # goto 110
      break
    }  
    } 
  }else{
    break
  }
}#End do Main

  v <- 0

  v[1:(m*(m+1)/2)] <- fu[1:(m*(m+1)/2)]

  istop <- 1

#! <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  pour les bandes de confiance
#! <-  <-  <-  <-  on ne retient que les para des splines

  derivaJ_list <- derivaJ(b,m,v,rl,k0,fctnames,model,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
               mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
               nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,np,
               ndatemax,memb,Kmat)
  v <- derivaJ_list[[1]]
  rl <- derivaJ_list[[2]]
  pe <- derivaJ_list[[3]]
  resnonpen <- derivaJ_list[[4]]
#!print*,"dans aaOptim, appel de derivaJ  with GAP vec funcpa... "
  if(rl == -1e+9){
    istop <- 4
    #goto 110
  }else{

    for(i in 1:(m*(m+3)/2)){
      v1[i] <- 0
    }
    
#!---- Choix du model

    if(model %in% c(1,7))m1 <- m-nva-effet-indic_alpha #!joint
    else if(model == 6)m1  <-  m - nva - effet*2 - indic_alpha*2
    else if(model == 5)m1 <- m-nva-effet-indic_alpha #!joint general (du moment que indic_eta <- indic_alpha <- 1)
    else if(model == 2)m1 <- m-nva-effet*2 #!additive
    else if(model == 3)m1 <- m-nva-effet #!nested
    else if(model == 4)m1 <- m-nva-effet #!shared
    

    kkk <- m1*(m1+1)/2

    for(i in 1:m1){
      kkk <- kkk+1  
      for(j in i:m1){
        k  <-  (((j-1)*j)/2) +i
        v1[k] <- v[k]/(4*b[i]*b[j])
      }
      v1[kkk] <- v1[kkk]+(v[kkk]/(4*b[i]*b[i]*b[i]))
    }
    ep <- 10e-10
    dsinvj_list <- dsinvj(v1,m1,ep,ier)
    
    v1 <- dsinvj_list[[1]]
    ier <- dsinvj_list[[2]]
    if(ier == -1){
#!         write(*,*)   echec inversion matrice information
      istop <- 3
    }
    

    for(i in 1:m1){
      for(j in i:m1){
        hess[i,j] <- v1[(j-1)*j/2+i]
      }
    }
    
    for(i in 2:m1){
      for(j in 1:(i-1)){
        hess[i,j] <- hess[j,i]
      }
    }
    

    ep <- 10e-10
    dsinvj_list <- dsinvj(v,m,ep,ier)
    
    v <- dsinvj_list[[1]]
    ier <- dsinvj_list[[2]]

    if(ier ==-1){
      istop <- 3
    }
    

    ep <- 10e-10
    derivaJ_list <-  derivaJ(b,m,vnonpen,rl,zero,fctnames,model,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                        mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                        nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,np,
                        ndatemax,memb,Kmat)
    
    vnonpen <- derivaJ_list[[1]]
    rl <- derivaJ_list[[2]]
    pe <- derivaJ_list[[3]]
    resnonpen <- derivaJ_list[[4]]
    for(i in 1:m){
      for(j in i:m){
        I_hess[i,j] <- vnonpen[(j-1)*j/2+i]
      }
    }

    for(i in 2:m){
      for(j in 1:(i-1)){
        I_hess[i,j] <- I_hess[j,i]
      }
    }

#!   H_hess est moins la hessienne inverse sur la vraisemblance penalisee
    for(i in 1:m){
      for(j in i:m){
        H_hess[i,j] <- v[(j-1)*j/2+i]
      }
    }
    
    for(i in 2:m){
      for(j in 1:(i-1)){
        H_hess[i,j] <- H_hess[j,i]
      }
    }


    if (typeof != 0){
      for(i in 1:(m*(m+1)/2)){
        vvv[i] <- v[i]
      }
    }else{vvv <- 0}

  }
  marq98j_list <- list(b,ni,v,rl,ier,istop,I_hess,H_hess,hess,vvv,ca, cb,dd,pe,resnonpen)
  marq98j_list
    
}


#!------------------------------------------------------------
#!                          DERIVA
#!------------------------------------------------------------

derivaJ <- function(b,m,v,rl,k0,fctnames,model,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                    mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                    nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,np,
                    ndatemax,memb,Kmat){

  fcith <- rep(0, m)
  endDeriva <- FALSE

  if(model %in% c(1,7))th <- 1e-3 #!joint
  else if(model == 5)th <- 1e-5 #!joint general !cas supplementaire rajoute
  else if(model== 2) th <- 5e-3 #!additive
  else if(model == 3)th <- 1e-5 #!nested
  else if(model == 4)th <- 1e-5 #!shared

  thn <- -th
  th2 <- th*th
  z <- 0
  i0 <- 0
  iun  <- 1


  rl_list <- fctnames(b,m,iun,z,iun,z,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                 mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                 nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                 ndatemax,memb,Kmat)

  rl <- rl_list[[1]]
  pe <- rl_list[[2]]
  resnonpen <- rl_list[[3]]
  if(rl != -1.e+9){
    for(i in 1:m){
      if((fcith[i] != -1.e+9) && (endDeriva == FALSE)){
        rl_list <- fctnames(b,m,i,th,i0,z,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                             mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                             nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                             ndatemax,memb,Kmat)
        fcith[i] <- rl_list[[1]]
        pe <- rl_list[[2]]
        resnonpen <- rl_list[[3]]
      }else{
        rl <- -1e+9
        endDeriva <- TRUE
      }
    }

    if(endDeriva == FALSE){
      k <- 0
      m1 <-  (m*(m+1)/2)
      ll <- m1

      for(i in 1:m){
        ll <- ll+1
        vaux_list <- fctnames(b,m,i,thn,i0,z,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                         mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                         nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                         ndatemax,memb,Kmat)
        vaux <- vaux_list[[1]]
        pe <- vaux_list[[2]]
        resnonpen <- vaux_list[[3]]
        if(vaux == -1e+9){
          rl <- -1e+9
          endDeriva <- TRUE
        }
        if(endDeriva == FALSE){
          vl <- (fcith[i]-vaux)/(2*th)
          v[ll] <- vl
          for(j in 1:i){
            k <- k+1
            v_list <- fctnames(b,m,i,th,j,th,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                                mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                                nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                                ndatemax,memb,Kmat)
                              pe <- v_list[[2]]
                              resnonpen <- v_list[[3]]
            v[k] <- -(v_list[[1]]-fcith[j]-fcith[i]+rl)/th2
          }
        }
      }
    }
  }

  derivaJ_list <- list(v,rl,pe,resnonpen)
  derivaJ_list
}

#!------------------------------------------------------------
#!                        SEARPAS
#!------------------------------------------------------------

searpasj <- function(vw,step,b,bh,m,delta,fim,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                     mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                     nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                     ndatemax,memb,Kmat){
#!
#!  MINIMISATION UNIDIMENSIONNELLE
#!
  goto <- 0
  vlw1 <- log(vw)
  vlw2 <- vlw1+step
  fi1_list <- valfpaj(vlw1,fi1,b,bh,m,delta,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                 mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                 nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                 ndatemax,memb,Kmat)
  fi1 <- fi1_list[[1]]
  pe <- fi1_list[[2]]
  resnonpen <- fi1_list[[3]]
  fi2_list <- valfpaj(vlw2,fi2,b,bh,m,delta,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                 mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                 nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                 ndatemax,memb,Kmat)
  fi2 <- fi2_list[[1]]
  pe <- fi2_list[[2]]
  resnonpen <- fi2_list[[3]]

  if(fi2 >= fi1){
    vlw3 <- vlw2
    vlw2 <- vlw1
    fi3 <- fi2
    fi2 <- fi1
    step <- -step

    vlw1 <- vlw2+step
    fi1_list <- valfpaj(vlw1,fi1,b,bh,m,delta,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                   mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                   nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                   ndatemax,memb,Kmat)
    fi1 <- fi1_list[[1]]
    pe <- fi1_list[[2]]
    resnonpen <- fi1_list[[3]]
    goto <- 0
    if(fi1 > fi2) goto <- 50
  }else{
    vlw <- vlw1
    vlw1 <- vlw2
    vlw2 <- vlw
    fim <- fi1
    fi1 <- fi2
    fi2 <- fim
  }
  if(goto != 50){
    i <- 1
    while(i <= 40){
      vlw3 <- vlw2
      vlw2 <- vlw1
      fi3 <- fi2
      fi2 <- fi1
      vlw1 <- vlw2+step
      fi1_list <- valfpaj(vlw1,fi1,b,bh,m,delta,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                     mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                     nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                     ndatemax,memb,Kmat)
      fi1 <- fi1_list[[1]]
      pe <- fi1_list[[2]]
      resnonpen <- fi1_list[[3]]
      if(fi1 > fi2){goto <- 50
      i <- 41
      }
      if(fi1==fi2){
        fim <- fi2
        vm <- vlw2
        goto <- 100
        i <- 41
      }
      i <- i+1
    }
  }

  if(goto != 100){
    vm <- vlw2-step*(fi1-fi3)/(2*(fi1-2*fi2+fi3))
    fim_list <- valfpaj(vm,fim,b,bh,m,delta,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                   mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                   nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                   ndatemax,memb,Kmat)
    fim <- fim_list[[1]]
    pe <- fim_list[[2]]
    resnonpen <- fim_list[[3]]
    if(fim > fi2){
      vm <- vlw2
      fim <- fi2
    }
  }

  vw <- exp(vm)

  vw_list <- list(vw, pe, resnonpen)
  vw_list
}

#!------------------------------------------------------------
#!                         DCHOLE
#!------------------------------------------------------------
dcholej <- function(a,k,nq,idpos){
  
  is <- rep(0, k)
  i2=0
  ii=0
  idpos=0
  k2=k+nq
  #!     calcul des elements de la matrice
  for(i in 1:k){
    ii=i*(i+1)/2
    #!       elements diagonaux
    diag=a[ii]
    i1=ii-i
    if(i-1 != 0){
      i2=i-1
      for(l in 1:i2){
        m=i1+l
        p=a[m]
        p=p*p
        if(is[l] < 0)p=-p
        diag=diag-p
      }
    }#else if(i-1 == 0){# goto 4
      if(diag < 0){# goto 5
        is[i]=-1
        idpos=idpos+1
        diag=-sqrt(-diag)
        a[ii]=-diag
        #goto 7
      }else if(diag > 0){
        is[i]=1
        diag=sqrt(diag)
        a[ii]=diag
      }else{
        break
      }
#    }
    #!       elements non diagonaux
    i3=i+1
    for(j in i3:k2){
      jj=j*(j-1)/2+i
      jmk=j-k-1
      if(jmk > 0)jj=jj-jmk*(jmk+1)/2
      term=a[jj]
      if(i-1 != 0){# goto 10
        for(l in 1:i2){
          iil=ii-l
          jjl=jj-l
          p=a[iil]*a[jjl]
          il=i-l
          if(is[il] < 0)p=-p # goto 11
          term=term-p
        }
      }
      a[jj]=term/diag
    }
  }

  #!       calcul des solutions
  jj=ii-k+1
  for(l in 1:nq){
    jj=jj+k
    i=k-1
    jji=jj+i
    xn=a[jji]
    if(i-k+1 < 0){# goto 20
      j=k-1
      jjj=jj+j  #21       
      ijm=i+1+j*(j+1)/2
      xn=xn-a[jjj]*a[ijm]
      while(j-i-1 > 0){ #goto 30
        j=j-1
        jjj=jj+j  #21       
        ijm=i+1+j*(j+1)/2
        xn=xn-a[jjj]*a[ijm]
      }
    }
    irm=(i+1)*(i+2)/2
    a[jji]=xn/a[irm]
    
    while(i > 0){
      i=i-1
      jji=jj+i
      xn=a[jji]
      if(i-k+1 < 0){# goto 20
        j=k-1
        jjj=jj+j  #21       
        ijm=i+1+j*(j+1)/2
        xn=xn-a[jjj]*a[ijm]
        while(j-i-1 > 0){ #goto 30
          j=j-1
          jjj=jj+j  #21       
          ijm=i+1+j*(j+1)/2
          xn=xn-a[jjj]*a[ijm]
        }
      }
      irm=(i+1)*(i+2)/2
      a[jji]=xn/a[irm]
    }  
  }
  
  dcholej_list <- list(a, idpos)
  dcholej_list
}


dmfsdj <- function(A,n,eps,ier){
  
  ier <- 0
  
  dpiv=0
  if(n-1>=0){
    kpiv=0
    for(k in 1:n){
      if(ier != -1){
      kpiv=kpiv+k
      ind=kpiv
      lend=k-1
      
      tol=abs(eps*A[kpiv])
      
      for(i in k:n){
        dsum=0
        if(lend != 0){# goto 2
          for(l in 1:lend){
            lanf=kpiv-l
            lind=ind-l
            dsum=dsum+A[lanf]*A[lind]
          }
        }# goto 4
          dsum=A[ind]-dsum
          if (i-k != 0){# goto 10
 #           print(paste("here10",dsum,dpiv,ind))
            A[ind]=dsum*dpiv
            ind=ind+i
          }else{# goto 5
            if(dsum-tol <= 0){# goto 6
              if(dsum <= 0){# goto 12
                ier = -1
                break
              }else{#goto 7
                if(ier <= 0)ier = k-1 #goto 8
                
              }
            }
            dpiv=sqrt(dsum)
    #        print(paste("here", dpiv,kpiv))
            A[kpiv]=dpiv
            dpiv=1/dpiv
            ind=ind+i
          }
        
        
      }
      }
    }   
  }else{
    ier=-1
  }
  dmfsdj_list <- list(A, ier)
  dmfsdj_list
}


#!------------------------------------------------------------
#  !                            DSINV
#!------------------------------------------------------------
  
dsinvj <- function(A,n,eps,ier){
  

  dmfsdj_list <- dmfsdj(A,n,eps,ier)
  A <- dmfsdj_list[[1]]
  ier <- dmfsdj_list[[2]]
  
  if(ier >= 0){
    ipiv=n*(n+1)/2
    ind=ipiv
    for(i in 1:n){
      din=1/A[ipiv]
      A[ipiv]=din
      min=n
      kend=i-1
      lanf=n-kend
      if(kend > 0){
        j=ind
        for(k in 1:kend){
          work=0
          min=min-1
          lhor=ipiv
          lver=j
          for(l in lanf:min){
            lver=lver+1
            lhor=lhor+l
            work=work+A[lver]*A[lhor]
          }
          A[j]=-work*din
          j=j-min
        }
      }
      ipiv=ipiv-min
      ind=ind-1
    }
    for(i in 1:n){
      ipiv=ipiv+i
      j=ipiv
      for(k in i:n){
        work=0
        lhor=j
        for(l in k:n){
          lver=lhor+k-i
          work=work+A[lhor]*A[lver]
          lhor=lhor+l
        }
        A[j]=work
        j=j+k
      }
    }
  }
  
  dsinvj_list <- list(A, ier)
  dsinvj_list
  
}

#!------------------------------------------------------------
#!                          VALFPA
#!------------------------------------------------------------

valfpaj <- function(vw,fi,b,bk,m,delta,k0,fctnames,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                    mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                    nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                    ndatemax,memb,Kmat){

  z <- 0
  i0 <- 1
  for(i in 1:m){
    bk[i] <- b[i]+exp(vw)*delta[i]
  }
  fi_list <- fctnames(bk,m,i0,z,i0,z,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                  mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                  nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                  ndatemax,memb,Kmat)
  
  fi_list[[1]] <- -fi_list[[1]]
  
  fi_list
}
#!------------------------------------------------------------
#!                            MAXT
#!------------------------------------------------------------
dmaxt <- function(maxt,delta,m){

  maxt <- abs(delta[1])

  for(i in 2:m){
    if(abs(delta[i]) > maxt){
      maxt <- abs(delta[i])
    }
  }
  maxt
}