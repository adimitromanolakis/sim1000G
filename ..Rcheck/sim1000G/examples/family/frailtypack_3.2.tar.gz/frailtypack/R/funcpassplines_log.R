

#! <-  <-  <  FUNCPA_SPLINES           <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <- 
funcpassplines_log <- function(b,np,id,thi,jd,thj,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                           mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                           nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                           ndatemax,memb,Kmat){
 
  funcpassplines_log <- 0
  cpt <- rep(0, ng)
  peT <- rep(0, nst)
  somT <- rep(0, nst)
  theT <- matrix(rep(0, (np+3)*nst), nrow  = np+3)
  bh <- rep(0, np)
  res1 <- rep(0, ng)
  res2 <- rep(0, ng)
  res3 <- rep(0, ng)
  res5 <- rep(0, nsujet)
  dutT <- matrix(rep(0, ndatemax*nst), nrow = ndatemax)
  utT <- matrix(rep(0, (ndatemax+1)*nst), nrow  =  ndatemax+1)
  integrale1 <- rep(0, length(unique(memb)))
  integrale3 <- rep(0, length(unique(memb)))
  
  j <- 0
  sig2 <- 0
  bh[1:np] <- b[1:np]
  
  
  
  if(id != 0) bh[id] <- bh[id]+thi
  if(jd != 0) bh[jd] <- bh[jd]+thj

  n  <-  (np-nva-effet)/nst
  for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
    for(i in 1:n){
      theT[i,jj] <- (bh[(jj-1)*n+i])*(bh[(jj-1)*n+i])
    }
  }
  
  #print(theT)
  if(effet == 1)sig2  <-  bh[np-nva]*bh[np-nva]
  
  
  #!---------  calcul de ut1(ti) et ut2(ti) ---------------------------
  #  !    attention the(1)  sont en nz <- 1
  #!        donc en ti on a the(i)
  
  vj  <-  4
  somT <- 0 #!en plus
  
  for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
    dutT[1,jj]  <-  (theT[1,jj]*4/(zi[5]-zi[4]))
    utT[1,jj]  <-  0
    utT[2,jj]  <-  theT[1,jj]*dutT[1,jj]*0.25*(zi[4]-zi[1])
  }
  
  
  for(i in 2:(ndate-1)){
    for(k in 5:(n-2+4)){
      if((date[i] >= zi[k-1]) && (date[i] < zi[k])){
        j  <-  k-1
        #       print(paste(j,k,date[i],zi[k-1],zi[k],vj))
        if((j > 4) && (j > vj)){
          for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
            somT[jj]  <-  somT[jj]+theT[j-4,jj]
          }
          vj   <-  j
        }
      }
    }
    for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
      utT[i+1,jj]  <-  somT[jj] +(theT[j-3,jj]*im3[i])+(theT[j-2,jj]*im2[i])+(theT[j-1,jj]*im1[i])+(theT[j,jj]*im[i])
      dutT[i,jj]  <-  (theT[j-3,jj]*mm3[i])+(theT[j-2,jj]*mm2[i])+(theT[j-1,jj]*mm1[i])+(theT[j,jj]*mm[i])
      #print(paste(i,j,utT[i+1,jj],dutT[i,jj]))
      
    }
  }
  i  <-  n-2
  h1  <-  (zi[i+3]-zi[i+2])
  #  print(h1)
  for(jj in 1:nst){
    utT[ndate+1,jj] <- somT[jj]+theT[i-1,jj]+theT[i,jj]+theT[i+1,jj]+theT[i+2,jj]
    dutT[ndate,jj]  <-  (4*theT[i+2,jj]/h1)
  }
  #print(utT[ndate+1,jj])
  #print(dutT[ndate,jj])
  #!-------------------------------------------------------
  #  !--------- calcul de la vraisemblance ------------------
  #!--------------------------------------------------------
  
  #  !--- avec ou sans variable explicative  ------cc
  
  #!*******************************************
  #  !---- sans effet aleatoire dans le modele
  #!*******************************************
  if (effet == 0){
    for(i in 1:nsujet){
      cpt[g[i]] <- cpt[g[i]]+1
      
      if(nva > 0){
        vet  <-  0
        for(j in 1:nva){
          vet  <- vet + bh[np-nva+j]*ve[i,j]
        }
        vet  <-  exp(vet)
      }else{
        vet <- 1
      }
      
      if(c[i] == 1){
        res2[g[i]]  <-  res2[g[i]]+log(dutT[nt1[i],stra[i]]*vet)
        #     print(nt1[i])
        #       print(paste(i,g[i],res2[g[i]],nt1[i],dutT[nt1[i],stra[i]],vet))
        #             break
      }
      if(abs(res2[g[i]]) >= 1e+30){
        funcpassplines_log <- -1e+9
        #go to 123
        break
      }
      
      res1[g[i]]  <-  res1[g[i]] + utT[nt1[i]+1,stra[i]]*vet-utT[nt0[i]+1,stra[i]]*vet
      #     RisqCumul[i]  <-  utT[nt1[i]+1,stra[i]]*vet
      
      if(abs(res1[g[i]]) >= 1e+30){
        funcpassplines_log <- -1e+9
        #goto 123
        break
      }
    }
    if(funcpassplines_log != -1e+9){
      res  <-  0
      cptg  <-  0
      
      #! k indice les groupes
      for(k in 1:ng){
        if(cpt[k] > 0){
          nb  <-  nig[k]
          res  <-  res-res1[k]+res2[k]
          cptg  <-  cptg + 1
          #       print(paste(k,res,res1[k],res2[k],nt1[k]))
          
          if(abs(res) >= 1e+30){
            funcpassplines_log <- -1e+9
            #goto 123
            break
          }
        }
      }
    }
    
    
    #!*********************************************
    #  !----avec un effet aleatoire dans le modele
    #!*********************************************
    
  }else{
    for(i in 1:nsujet){
      cpt[g[i]] <- cpt[g[i]]+1
      if(nva > 0){
        vet  <-  0
        for(j in 1:nva){
          vet  <- vet + bh[np-nva+j]*ve[i,j]
        }
        vet  <- exp(vet)
      }else{
        vet <- 1
      }
      if(c[i] == 1){
        res2[g[i]]  <-  res2[g[i]]+log(dutT[nt1[i],stra[i]]*vet)
      }
      #      print(paste(i,c[i],res2[g[i]],dutT[nt1[i],stra[i]],vet))
      #     break
      if(abs(res2[g[i]]) >= 1e+30){
        funcpassplines_log <- -1e+9
        #goto 123
        break
      }
      
      res3[g[i]] <- res3[g[i]] + utT[nt0[i]+1,stra[i]]*vet 
      res5[i] <- utT[nt1[i]+1,stra[i]]*vet
      res1[g[i]] <- res1[g[i]] + res5[i]
      
      if(abs(res1[g[i]]) >= 1e+30){
        funcpassplines_log <- -1e+9
        #goto 123
        break
      }
      
      if(abs(res5[g[i]]) >= 1e+30){
        funcpassplines_log <- -1e+9
        #goto 123
        break
      }
    }
    
 #   !**************INTEGRALES ****************************
    index <- 1
   # mat <- Kmat[(index):(index+length(which(memb==memb[1]))-1),(index):(index+length(which(memb==memb[1]))-1)]
    for(ig in 1:length(unique(memb))){
      nmemb <- length(which(memb==ig))
      mat <- Kmat[(index):(index+nmemb-1),(index):(index+nmemb-1)]
      det <- determinant(mat)$modulus[1]
      c_fam <- c[which(memb==ig)]
      res_fam <- res5[which(memb==ig)]
      choix = 1
      integrale1[ig] <- gauherS(0,choix,ig,0,nsujet,g,c_fam,res_fam,nig,sig2,det,mat,nmemb)
      if(AG == 1){
        choix = 3
        integrale3[ig] <- gauherS(0,choix,ig,0,nsujet,g,c,(res1[ig]-res3[ig]),nig,sig2,det,mat,nmemb)
      }
    #  if(indictronq.eq.1) then
    #  choix = 2
    #  call gauherS(int,choix)
    #  integrale2(ig) = int
    #  endif
    }
   #   !************* FIN INTEGRALES ************************
    
    
    
    
    res  <-  0
    
    if(funcpassplines_log != -1e+9){
      for(k in 1:ng){
        if(AG == 1){
          res <-  res+res2[k]-log(sqrt(sig2))-log(2*pi)/2+ log(integrale3[k])
         }else{
           res  <-  res+res2[k]+log(integrale1[k])#-log(integrale2[k])
         }
        
        if(abs(res) >= 1e+30){
          funcpassplines_log <- -1e+9
              #goto 123
           break
         }
        }
      }
    }#fin boucle effet <- 0
  
  
  #!--------- calcul de la penalisation -------------------
  if(funcpassplines_log != -1e+9){ 
    
    peT=0
    pe=0
    for(jj in 1:nst){#} !en plus strates A.Lafourcade 05/2014
      for(i in 1:(n-3)){
        
        peT[jj]  <-  peT[jj]+(theT[i,jj]*theT[i,jj]*m3m3[i])+
          (theT[i+1,jj]*theT[i+1,jj]*m2m2[i])+
          (theT[i+2,jj]*theT[i+2,jj]*m1m1[i])+
          (theT[i+3,jj]*theT[i+3,jj]*mmm[i])+
          (2*theT[i,jj]*theT[i+1,jj]* m3m2[i])+
          (2*theT[i,jj]*theT[i+2,jj]*m3m1[i])+
          (2*theT[i,jj]*theT[i+3,jj]*m3m[i])+
          (2*theT[i+1,jj]*theT[i+2,jj]*m2m1[i])+
          (2*theT[i+1,jj]*theT[i+3,jj]*m2m[i])+
          (2*theT[i+2,jj] *theT[i+3,jj]*m1m[i])
      }
    } 
    for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
      pe <- pe+peT[jj]*k0T[jj]
    }

    resnonpen  <-  res
    res  <-  res - pe
    
    if(abs(res) >= 1e+30){
      funcpassplines_log <- -1e+9
      #goto 123
    }else{
      funcpassplines_log  <-  res
      # for(k in 1:ng){
      #   if(AG == 1){
      #     cumulhaz[k] <- res1[k]-res3[k]
      #   }else{ 
      #     cumulhaz[k] <- res1[k]
      #   }
      # }
    }
    
  }
  
  funcpassplines_log_list <- list(funcpassplines_log, pe, resnonpen)
  funcpassplines_log_list
}



#!=============================================================
#  ! gauss hermite
#! func est l integrant, ss le resultat de l integrale sur -infty , +infty

gauherS <- function(ss,choix,auxig,typeof,nsujet,g,c,res,nig,sig2,detK,Kmat,nmemb){


  ss <- 0
  if(typeof == 0)n.nodes <- 15
  else n.nodes <- 32

  
# #   nodes <- gauss.quad(n.nodes,kind="hermite")$nodes
##    weights <- gauss.quad(n.nodes,kind="hermite")$weights*exp(nodes^2)
#  lappend <- function (lst, ...){
#    lst <- c(lst, list(...))
#    return(lst)
#  }
#  nodes <- gauss.quad(n.nodes,kind="hermite")$nodes
#  weights <- gauss.quad(n.nodes,kind="hermite")$weights*exp(nodes^2)
# 
#  tmp <- rep(list(nodes),28)
#  names(tmp) <- 1:28
# 
# nodess1 <- expand.grid.id(1:(15^5), tmp)
# print(tail(nodess1))
# tmp2 <- tmp;  tmp2[[6]] <- tmp[[6]][-1]
# nodess2 <- expand.grid.id(1:(15^5), tmp2)
# print(tail(nodess2))
# tmp2 <- tmp;  tmp2[[6]] <- tmp[[6]][-2]
# nodess3 <- expand.grid.id(1:(15^5), tmp2)
# tmp2 <- tmp;  tmp2[[6]] <- tmp[[6]][-3]
# nodess4 <- expand.grid.id(1:(15^5), tmp2)
# tmp2 <- tmp;  tmp2[[6]] <- tmp[[6]][-4]
# nodess5 <- expand.grid.id(1:(15^5), tmp2)
# tmp2 <- tmp;  tmp2[[6]] <- tmp[[6]][-2]
# nodess3 <- expand.grid.id(1:(15^5), tmp2)
# 
#
# 
# 
# tmp <- rep(list(weights), 5)
# tmp <- lappend(tmp)
# weights <- as.data.frame(expand.grid(tmp))
# print(dim(weights))
 
  integrand <- function(b,nsujet,sig2,detK,Kmat) {
   
        prod = prod((exp(b)**c) *exp(-exp(b)*res))
     

    ff <- prod*(1/sqrt((2*pi)^nsujet*sig2*abs(detK)))*exp(-0.5*t(b)%*%solve(sig2*2*Kmat)%*%b)

    return(ff)
  } # End integrand
  print(nmemb)
  NDIM <- nmemb
  NCOMP <- 1
  int <-cuhre(NDIM, NCOMP,  integrand,nsujet,sig2,detK,Kmat, lower = rep(-12, NDIM), upper = rep(12, NDIM),
        rel.tol= 1e-3, abs.tol= 1e-12,
        flags= list(verbose=2, final=0))
  print(warnings())
  int$value
#    if(choix ==1){
#      prod = 1
#      for(i in 1:nsujet){
#        if(g[i] == auxig){
#          print("here")
#          print(head(exp(nodes)**c[i]))
#          break
#          prod = prod * (exp(nodes)**c[i]) *exp(-exp(nodes)*res[i])
#        }
#      }
#    
#      func1S <- prod*(1/sqrt((2*pi)^nsujet*sig2*detK))*exp(-0.5*t(nodes)%*%solve(sig2*2*Kmat)%*%nodes)
#    }else{
#      func1S <- exp(nodes*nig[auxig]-exp(nodes)*res-(nodes**2)/(2*sig2))
#    }
#      
#    ss <- sum(weights %*% func1S)
  
#    ss
}


expand.grid.id  <- function(id, vars) {
  # vars <- list(...)
  nv <- length(vars)
  lims <- sapply(vars,length)
 # stopifnot(length(lims) > 0, id <= prod(lims), length(names(vars)) == nv)
  
  res <- structure(vector("list",nv), .Names = names(vars))
  if (nv > 1) for(i in nv:2) {
    f <- prod(lims[1:(i-1)])
    res[[i]] <- vars[[i]][(id - 1)%/%f + 1]
    
   
    id <- (id - 1)%%f + 1
  }
  res[[1]] <- vars[[1]][id]
  as.data.frame(res)
}