frailtypack <- function(nsujet, ng, icen, nst, effet, 
                        nz, axT, tt0, tt1, ic, groupe, nva, str, vax, 
                        AG, noVar, maxiter, irep1, np, b, H_hessOut, HIHOut, resOut, LCV, 
                        xTOut, lamTOut, xSuT, suTOut, typeof, equidistant, nbintervR, mt,  
                        ni, cpt, ier, k0, ddl, istop, shapeweib, scaleweib, mt1, ziOut, Resmartingale, martingaleCox, 
                        frailtypred, frailtyvar, frailtysd, linearpred, time, intcens, ttU, logNormal,  
                        timedep, nbinnerknots, qorder, filtretps, BetaTpsMat, EPS, Kmat, memb){
  

  
  detK <- determinant(Kmat)$modulus[1]


  
  resnonpen <- 0
  
#cpm
  istopp <- rep(0, 2)
  time <- 0
  
  #AD:add for new marq
  epsa <- EPS[1] 
  epsb <- EPS[2] 
  epsd <- EPS[3]
  #AD:end
  
#  npbetatps <- (nbinnerknots+qorder-1)*sum(filtretps)
  model <- 4
  RisqCumul <- rep(0, nsujet)
  
  if (typeof == 0){
    nt0 <- rep(0, nsujet)
    nt1 <- rep(0, nsujet)
    ntU <- rep(0, nsujet)
  }
   c <- rep(0, nsujet)
  g <- rep(0, nsujet)
  
  ndatemax <- 2*nsujet+sum(ic) # on ajoute le nombre de temps dentree en plus : les tU
  # cest a dire le nombre de censures par intervalle
  
  date <- rep(0, ndatemax)
  
   mm <- rep(0, ndatemax)
  mm1 <- rep(0, ndatemax)
  mm2 <- rep(0, ndatemax)
  mm3 <- rep(0, ndatemax)
  im3 <- rep(0, ndatemax)
  im2 <- rep(0, ndatemax)
  im1 <- rep(0, ndatemax)
  im <- rep(0, ndatemax)
  
  nzmax <- nz+3
  
  m3m3 <- rep(0, nzmax)
  m2m2 <- rep(0, nzmax)
  m1m1 <- rep(0, nzmax)
  mmm <- rep(0, nzmax)
  m3m2 <- rep(0, nzmax)
  m3m1 <- rep(0, nzmax)
  m3m <- rep(0, nzmax)
  m2m1 <- rep(0, nzmax)
  m2m <- rep(0, nzmax)
  m1m <- rep(0, nzmax)
  
  
 nig <- rep(0, ng)
    j<- 0
  nbou2 <- 0
  id<- 1    
  cptni <- 0
  cptni1 <- 0
  cptni2 <- 0
  cptbiais <- 0

    
    pe <- 0
  
  ndate=0
  ibou=1
  ij=0
  kk=0
  ni=0
  cpt=0
  
  resOut <- 0
  
  etaT <- rep(0, nst)
  betaT <- rep(0, nst)
 nstRec <- 0 # dans marq98j de distinguer le modele shared du modele joint
  shapeweib <- 0
  scaleweib <- 0
  lamTOut <- 0
  suTOut <- 0
  
  filtre <- rep(0, nva)
 
  if(noVar == 1){ 
    for(i in 1:nva){
      filtre[i] <- 0
  }}else{
    for(i in 1:nva){
      filtre[i] <- 1
    }} 
  
  ver <- nva
  nvarmax <- ver
  ve <- matrix(rep(0, nva*nsujet),nrow = nsujet, ncol = nva)
  res <- 0
  v <- 0
  
   
  #**************************************************
  #**************************************************
  #********************* prog spline****************
  
  res01 <- 0
  
  
  t0 <- rep(0, nsujet)
  t1 <- rep(0, nsujet)
  tU <- rep(0, nsujet)
  c <- rep(0, nsujet)
  stra <- rep(0, nsujet)
  g <- rep(0, nsujet)
  
  #------------  lecture fichier -----------------------
  
  maxt <- 0
  mint <- 0
  
  cpt <- 0
  k <- 0
  cptstr1 <- 0
  cptstr2 <- 0
  
 vax_vector <- rep(0, nva)
  
  for(i in 1:nsujet){
    str_scalar <- 1
    if(i == 1)mint = tt0[i] # affectation du min juste une fois
    if(nst >= 2){
      tt0_scalar <- tt0[i]
      tt1_scalar <- tt1[i]
      ttU_scalar <- ttU[i]
      ic_scalar <- ic[i]
      groupe_scalar <- groupe[i]
      str_scalar <- str[i]
  
      for(j in 1:nva){
        vax_vector[j] <- vax[i,j]
      }
    }else{
      tt0_scalar <- tt0[i]
      tt1_scalar <- tt1[i]
       ttU_scalar <- ttU[i]
      ic_scalar <- ic[i]
      groupe_scalar <- groupe[i]
  
      for(j in 1:nva){
        vax_vector[j] <- vax[i,j]
      }
    }
  k <- k +1
  
  #     essai sans troncature
  #------------------   observation c=1
  if(ic_scalar == 1){
    cpt <- cpt + 1
    c[k] <- 1
    stra[k] <- str_scalar # pas besoin de if et des compteurs
    t0[k] <- tt0_scalar
    t1[k] <- tt1_scalar
    tU[k] <- ttU_scalar
    g[k] <- groupe_scalar
  
  # nb de dc dans un groupe
  # attention on a un nombre de groupes, mais le numero de groupe peut depasser la liste
    nig[groupe_scalar] <- nig[groupe_scalar] + 1
  
    iii <- 0
    for(ii in 1:ver){
      if(filtre[ii] == 1){
        iii <- iii + 1
        ve[i,iii] <- vax_vector[ii]
      }
    }
   
  }else{
  #!------------------   censure a droite  c=0
    if(ic_scalar == 0){
      c[k] <- 0 
      stra[k] <- str_scalar #en plus strates A.Lafourcade 05/2014
      iii <- 0
      for(ii in 1:ver){
        if(filtre[ii] == 1){
          iii <- iii + 1
          ve[i,iii] <- vax_vector[ii]
        }
      }
  
    t0[k] <- tt0_scalar
    t1[k] <- tt1_scalar
    tU[k] <- ttU_scalar
    g[k] <- groupe_scalar
    }
  }
  
  if(maxt < t1[k])maxt <- t1[k]
  
  if((maxt < tU[k]) && (tU[k] != t1[k]))maxt = tU[k]

  if(mint > t0[k])mint <- t0[k]
  
  }
  
 cens = maxt
 
  # creation de d : nombre de censures par intervalle dans chaque groupe
  
  d <- rep(0, ng)
  for(i in 1:nsujet){
    if(c[i] == 1)d[g[i]] <- d[g[i]] + 1
  }
  
  dmax <- 0
  for(i in 1:ng){
    if(dmax < d[i])dmax <- d[i] # max number of subject avec event=1( interval censored) by group
  }
  
  
  # %%%%%%%%%%%%% SANS EFFET ALEATOIRE %%%%%%%%%%%%%%%%%%%%%%%%%
  
  nsujet <- k
  
  if(typeof == 0){    
    nz1 <- nz
    nz2 <- nz
  
    if(nz > 20)nz <- 20
    if(nz < 4)nz <- 4
  }
  #***************************************************
  #-------------- zi- ----------------------------------
  #      construire vecteur zi (des noeuds)

  
  min <- 1.e-10
  max <- maxt
  aux <- rep(0, 3*nsujet)
  
  for(i in 1:(2*nsujet+sum(ic))){# ! changement comme indique plus haut
    for(k in 1:nsujet){
      if(t0[k] >= min){
        if(t0[k] < max)max <- t0[k]
      }
      if(t1[k] >= min){
        if(t1[k] < max)max <- t1[k]
      }
      if(tU[k] != t1[k]){
        if((tU[k] >= min)){
          if(tU[k] < max)max <- tU[k]
        }
      }
    }
    aux[i] <- max
    min <- max + 1.e-12 # pour virer les doublons
    max <- maxt
  }
  
  date[1] <- aux[1]
  
  k <- 1
  for(i in 2:(2*nsujet+sum(ic))){
    if(aux[i] > aux[i-1]){
      k <- k+1
      date[k] <- aux[i]
    }
  }
  
  if(typeof == 0){
  #emplacement des noeuds splines en percentile (sans censure par intervalle)
    if(equidistant == 0){ #percentile
      i <- 0
      j <- 0
  #!----------> taille - nb de recu
      for(i in 1:nsujet){
        if(t1[i] != 0 && c[i] == 1)j <- j+1
      }
      nbrecu <- j
  
  #!----------> allocation des vecteur temps
      t2 <- rep(0, nbrecu)
  
  #!----------> remplissage du vecteur de temps
      j <- 0
      for(i in 1:nsujet){
        if(t1[i] != 0 && c[i] == 1){
          j <- j+1
          t2[j] <- t1[i]
        }
      }
  
      nzmax <- nz+3
  
      zi <- rep(0, nzmax+3)
      ndate <- k
  
      zi[1] <- mint   #-2
      zi[2] <- mint   #-1
      zi[3] <- mint   #0
      zi[4] <- mint   #1
      j <- 0
      for(j in 5:(nz-2+3)){
        pord <- j/(nz-1)
        zi[j+4] <- quantile(t2, pord)
      }
      zi[nzmax] = maxt 
      zi[nzmax+1] = maxt 
      zi[nzmax+2] = maxt 
      zi[nzmax+3] = maxt 
      ziOut = zi
 
    }else{ #! equidistant
      nzmax <- nz+3
      zi <- rep(0, nzmax+3)
      ndate <- k
  
      zi[1] <- mint
      zi[2] <-  mint
      zi[3] <-  mint
      zi[4] <-  mint
      h <- (date[ndate]- mint)/(nz-1)
      for(i in 5:(nz-1+4)){
        zi[i] <- zi[i-1] + h
      }
      zi[nzmax] <- maxt
      zi[nzmax+1] <- maxt
      zi[nzmax+2] <- maxt 
      zi[nzmax+3] <- maxt
      ziOut <- zi
    }

 # !--------- affectation nt0,nt1,ntU----------------------------
    indictronq <- 0
    for(i in 1:nsujet){
      if(t0[i] == 0)nt0[i] <- 0
      if(t0[i] != 0)indictronq <- 1
  
  
      for(j in 1:ndate){
        if(date[j] == t0[i])nt0[i] <- j
        if(date[j] == t1[i])nt1[i] <- j
  
        if(date[j] == tU[i])ntU[i] <- j
      }
    }
  
 # !--------- affectation des vecteurs de splines -----------------
    n = nz+2

    vecsplis_list <- vecsplis(n,ndate,date,zi,mm2,mm3,mm1,mm,im3,im2,im1,im)
  mm2 <- vecsplis_list[[1]]
  mm3 <- vecsplis_list[[2]]
  mm1 <- vecsplis_list[[3]]
  mm <- vecsplis_list[[4]]
  im3 <- vecsplis_list[[5]]
  im2 <- vecsplis_list[[6]]
  im1 <- vecsplis_list[[7]]
  im <- vecsplis_list[[8]]


    vecpens_list <- vecpens(n,zi,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m)
    m3m3 <- vecpens_list[[1]]
    m2m2 <- vecpens_list[[2]]
    m1m1 <- vecpens_list[[3]]
    mmm <- vecpens_list[[4]]
    m3m2 <- vecpens_list[[5]]
    m3m1 <- vecpens_list[[6]]
    m3m <- vecpens_list[[7]]
    m2m1 <- vecpens_list[[8]]
    m2m <- vecpens_list[[9]]
    m1m <- vecpens_list[[10]]
  }

  k0T <- rep(0, nst)
  H_hess <- matrix(rep(0, np^2), nrow = np, ncol = np)
  I_hess <- matrix(rep(0, np^2), nrow = np, ncol = np)
  Hspl_hess <- matrix(rep(0, np^2), nrow = np, ncol = np)
  hess <- matrix(rep(0, np^2), nrow = np, ncol = np)
  HI <- matrix(rep(0, np^2), nrow = np, ncol = np)
  
 # !------ initialisation des parametres
  
 # ! savoir si lutilisateur entre des parametres initiaux

  if(sum(b) == 0){
    b <- rep(1e-1, np)
  }else if(sum(b[(np-nva+1):np]) == 0){
    b[1:(np-nva-1)] <- 1e-1
    b[(np-nva+1):np] <- 1e-1
  }else if(b[np-nva] == 0){
    b[1:(np-nva-1)] <- 1e-1
    b[np-nva] <- 1e-1
  }else{
    b[1:(np-nva-1)] <- 1e-1
  }
  
  if(typeof == 1){
    b[(nbintervR+1):(nst*nbintervR)]=0.2
  }
  xmin1 <- axT[1]
  if(nst >= 2){
    xmin2 <- axT[2]
  }else{
    xmin2 <- 0
  }
  if(nst >= 2){
    for(l in 2:nst){
      xminT[l] <- axT[l]
    }
  }
  #!fin strates

  ent <- 0
  entTPS <- 0
  indd <- 1
  

  if(typeof == 1){
    if(intcens == 0){# !! enlever le piecewise-per pour la censure par intervalle
#  !------- RECHERCHE DES NOEUDS
 # !----------> Enlever les zeros dans le vecteur de temps
    i <- 0
    j <- 0
  
  #!----------> taille - nb de recu
    for(i in 1:nsujet){
      if(t1[i] != 0 && c[i] == 1)j=j+1
    }
  
    nbrecu <- j
  
    n <- nbintervR
  #!----------> allocation des vecteur temps
    t2 <- rep(0, nbrecu)
  
  #!----------> remplissage du vecteur de temps
    j <- 0
    for(i in 1:nsujet){
      if(t1[i] != 0 && c[i] == 1){
        j <- j+1
        t2[j] <- t1[i]
      }
    }
  
  #!----------> tri du vecteur de temps
    indd <- 1
    while(indd == 1){
      indd <- 0
      for(i in 1:(nbrecu-1)){
        if(t2[i] > t2[i+1]){
          temp <- t2[i]
          t2[i] <- t2[i+1]
          t2[i+1] <- temp
          indd <- 1
        }
      }
    }
    
  
  ent <- round(nbrecu/nbintervR, 0)
    }
  
  ttt <- rep(0,nbintervR)
  
  ttt[0] <- mint #!0.d0 pour prendre en compte une eventuelle troncature
  
  ttt[nbintervR] <- cens
  j<-0
  for(j in 1:(nbintervR-1)){
    if(equidistant == 0){# ! ici se fait la difference entre piecewise-per et equi
      ttt[j] <- (t2[ent*j]+t2[ent*j+1])/2
    }else{
      ttt[j] = mint + ((cens-mint)/nbintervR)*j
    }
    
  }
  
  
  if(intcens == 0){

  time <- ttt
  
  }#  !------- FIN RECHERCHE DES NOEUDS
  
  }
  
  
  if(typeof != 1){
  
    if(intcens == 0){ # !! enlever le piecewise-per pour la censure par intervalle
 # !------- RECHERCHE DES NOEUDS
  #!----------> Enlever les zeros dans le vecteur de temps
      i <- 0
      j <- 0
  
  #!----------> taille - nb de recu
      for(i in 1:nsujet){
        if(t1[i] != 0 && c[i] == 1)j <- j+1
      }
      
      nbrecu <- j
  
  #!----------> allocation des vecteur temps
      t2 <- rep(0, nbrecu)
  #  !----------> remplissage du vecteur de temps
      j <- 0
      for(i in 1:nsujet){
        if(t1[i] != 0 && c[i] == 1){
          j <- j+1
          t2[j] <- t1[i]
        }
      }
  
  #!----------> tri du vecteur de temps
      indd <- 1
      while(indd == 1){
        indd <- 0
        for(i in 1:(nbrecu-1)){
          if(t2[i] > t2[i+1]){
            temp <- t2[i]
            t2[i] <- t2[i+1]
            t2[i+1] <- temp
            indd <- 1
          }
        }
      }
  
    }
  }
  #!------- FIN RECHERCHE DES NOEUDS
  
  #!***********************************************************
  #  !************** NEW : cross validation  ***********************
  #  !       sur une seule strate, sans var expli , sans frailties ****
  #  !***********************************************************
    
    
  nvacross <- nva #!pour la recherche du parametre de lissage sans var expli
  nva <- 0
  effetcross <- effet
  effet <- 0
  nstcross <- nst
  nst=1
  stracross <- rep(0, nsujet) 
  
  for(l in 1:nsujet){  
    stracross[l] <- stra[l]
  }
  
  for(l in 1:nsujet){
    stra[l] <- 1
  }
  
  y <- matrix(rep(0, np^2), nrow = np)
  if(typeof == 0){
    if(irep1 == 1){#   !pas recherche du parametre de lissage
      xmin1 <- sqrt(xmin1)
   
      auxi <- estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
  
      ni <- auxi[[7]]
      b[1:n] <- auxi[[4]]
      ddl <- auxi[[6]]
      if (ni >= maxiter){
        for(i in 1:(nz+2)){
          b[i] <- 1e-1
        }
        xmin1 <- sqrt(10)*xmin1
        auxi <- estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                        im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                        m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                        model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                        nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
        ni <- auxi[[7]]
        b[1:n] <- auxi[[4]]
        ddl <- auxi[[6]]
        if (ni >= maxiter){
          for(i in 1:(nz+2)){
            b[i]=1e-1
          }
          xmin1 <- sqrt(10)*xmin1
          auxi <- estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                      im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                      m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                      model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                      nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
          ni <- auxi[[7]]
          b[1:n] <- auxi[[4]]
          ddl <- auxi[[6]]
        }
      }
    }else{ 
  #!---------------------------------------------------
            #          !recherche du parametre de lissage

      if(xmin1 <= 0)xmin1 <- 1
      xmin1 = sqrt(xmin1)
      auxi = estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                   im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                   m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                   model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                   nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
   
      ddl <- auxi[[6]]
      b[1:n] <- auxi[[4]]
      if(ddl > -2.5){
         xmin1 = sqrt(xmin1)
         auxi = estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
         ddl <- auxi[[6]]
         b[1:n] <- auxi[[4]]
        if(ddl > -2.5){
          xmin1 <- sqrt(xmin1)
          auxi = estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                       im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                       m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                       model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                       nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
          ddl <- auxi[[6]]
          b[1:n] <- auxi[[4]]

          if(ddl > -2.5){
            xmin1 <- sqrt(xmin1)
              auxi = estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                         im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                         m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                         model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                         nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
              ddl <- auxi[[6]]
              b[1:n] <- auxi[[4]]

            if(ddl > -2.5){
              xmin1 <- sqrt(xmin1)
              auxi = estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                           im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                           m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                           model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                           nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
              ddl <- auxi[[6]]
              b[1:n] <- auxi[[4]]
              if(ddl > -2.5){
                xmin1 <- sqrt(xmin1)
              }
            }
          }
        }
      }
      ni <- auxi[[7]]
      if(ni >= maxiter){
        for(i in 1:(nz+2)){
          b[i] <- 1e-1
        }
        xmin1 <- sqrt(10)*xmin1
        auxi = estimvs(xmin1,n,b,y,ddl,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                       im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                       m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                       model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                       nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
        ni <- auxi[[7]]
        b[1:n] <- auxi[[4]]
        ddl <- auxi[[6]]
        if(ni >= maxiter){
          for(i in 1:(nz+2)){
            b[i] <- 1e-1
          }
          xmin1 <- sqrt(10)*xmin1
        }
      }
      ax <- xmin1
      bx <- xmin1*sqrt(1.5)
      mnbraks_list <- mnbraks(ax,bx,cx,fa,fb,fc,b,n,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                              im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                              m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                              model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                              nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)

      ax <- mnbraks_list[1]
      bx <- mnbraks_list[2]
      cx <- mnbraks_list[3]
      fa <- mnbraks_list[4]
      fb <- mnbraks_list[5]
      fc <- mnbraks_list[6]

      tol = 0.001

      res <- goldens(ax,bx,cx,tol,xmin1,n,b,y,ddl,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,np,memb,Kmat)
     
      auxkappa <- c(xmin1*xmin1, 0)
    
      if(logNormal == 0){
        if(intcens == 1){
   #       call marq98j(auxkappa,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_intcens)
        }else{
          marq98j_list <- marq98j(auxkappa,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines,nva,
                                  model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                                  m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                                  mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                                  nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                                  ndatemax,memb,Kmat) 
          
           b <- marq98j_list[1]
          ni <- marq98j_list[2]
          v <- marq98j_list[3]
          res <- marq98j_list[4]
          ier <- marq98j_list[5]
          istop <- marq98j_list[6]
          I_hess <- marq98j_list[7]
          H_hess <- marq98j_list[8]
          hess <- marq98j_list[9]
          vvv <- marq98j_list[10]
          epsa <- marq98j_list[11]
          epsb <- marq98j_list[12]
          epsd <- marq98j_list[13]
          pe <- marq98j_list[[14]]
          resnonpen <- marq98j_list[[15]]
     #     call marq98j(auxkappa,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines) TUTAJ
        }
      }else{
    #    call marq98j(auxkappa,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_log)
        marq98j_list <- marq98j(auxkappa,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_log,nva,
                                model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                                m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                                mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                                nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                                ndatemax,memb,Kmat) 
        
        b <- marq98j_list[1]
        ni <- marq98j_list[2]
        v <- marq98j_list[3]
        res <- marq98j_list[4]
        ier <- marq98j_list[5]
        istop <- marq98j_list[6]
        I_hess <- marq98j_list[7]
        H_hess <- marq98j_list[8]
        hess <- marq98j_list[9]
        vvv <- marq98j_list[10]
        epsa <- marq98j_list[11]
        epsb <- marq98j_list[12]
        epsd <- marq98j_list[13]
        pe <- marq98j_list[[14]]
        resnonpen <- marq98j_list[[15]]
      }

      if(istop != 1){
        istopp[1] <- 1
#goto 1000
      }
    }
  }
  nva=nvacross #! pour la recherche des parametres de regression
  nst=nstcross #! avec stratification si necessaire
  effet=effetcross #! avec effet initial

  for(l in 1:nsujet){
    stra[l]=stracross[l] #!retablissement stratification
  }
  
  if(typeof != 0){
    vvv <- rep(0, np*(np+1)/2)
  }
  
  if(typeof == 0){
    k0[1]  <- xmin1*xmin1
    if(nst == 2){
      k0[2] = xmin2
    }
    k0T[1] = xmin1*xmin1 #!en plus strates A.Lafourcade 05/2014
    if(nst >= 2){
      for(l in 2:nst){
        k0T[l] <- xminT[l]
      }
    }
  }
#!------------  indicateur deffet aleatoire ou non dans le modele

  ca=0
  cb=0
  dd=0
  if(typeof == 0){
    if(timedep ==  0){
      if(logNormal == 0){
        if(intcens == 1){
 #         call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_intcens)
        }else{
          marq98j_list <- marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines,nva,
                                  model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                                  m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                                  mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                                  nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                                  ndatemax,memb,Kmat) 
          
          b <- marq98j_list[[1]]
          ni <- marq98j_list[[2]]
          v <- marq98j_list[[3]]
          res <- marq98j_list[[4]]
          ier <- marq98j_list[[5]]
          istop <- marq98j_list[[6]]
          I_hess <- marq98j_list[[7]]
          H_hess <- marq98j_list[[8]]
          hess <- marq98j_list[[9]]
          vvv <- marq98j_list[[10]]
          epsa <- marq98j_list[[11]]
          epsb <- marq98j_list[[12]]
          epsd <- marq98j_list[[13]]
          pe <- marq98j_list[[14]]
          resnonpen <- marq98j_list[[15]]
        }
      }else{
 #       call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_log)
        marq98j_list <- marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_log,nva,
                                model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                                m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                                mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                                nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                                ndatemax,memb,Kmat) 
        
        b <- marq98j_list[[1]]
        ni <- marq98j_list[[2]]
        v <- marq98j_list[[3]]
        res <- marq98j_list[[4]]
        ier <- marq98j_list[[5]]
        istop <- marq98j_list[[6]]
        I_hess <- marq98j_list[[7]]
        H_hess <- marq98j_list[[8]]
        hess <- marq98j_list[[9]]
        vvv <- marq98j_list[[10]]
        epsa <- marq98j_list[[11]]
        epsb <- marq98j_list[[12]]
        epsd <- marq98j_list[[13]]
        pe <- marq98j_list[[14]]
        resnonpen <- marq98j_list[[15]]
      }
    }else{
  #    call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpas_tps)
    }
  }else if(typeof == 1){
    betacoef <- rep(0, nst*nbintervR)
    if(timedep == 0){
      if(logNormal == 0){
        if(intcens == 1){
     #     call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpascpm_intcens)
        }else{
   #       call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpascpm)
        }
      }else{
  #      call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpascpm_log)
      }
    }else{
  #    call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpas_tps)
    }
  }else if(typeof == 2){
    if(timedep == 0){
      if(logNormal == 0){
        if(intcens == 1){
     #     call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpasweib_intcens)
        }else{
    #      call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpasweib)
        }
      }else{
   #     call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpasweib_log)
      }
    }else{
   #   call marq98j(k0,b,np,ni,v,res,ier,istop,effet,ca,cb,dd,funcpas_tps)
    }
  }
  
  EPS[1] <- epsa
  EPS[2] <- epsb
  EPS[3] <- epsd
  
  
  if(istop != 1){
    istopp[2] <-1
#goto 1000
  }else{
    IH <- I_hess%*%H_hess
    HIH <- H_hess%*%IH
  
    if(effet == 1 && ier == -1){
      v[(np-nva)*(np-nva+1)/2] <- 10
    }
  
    res01[effet+1]=res
  

  
        #! --------------  Lambda and survival estimates JRG January 05
  
    if(typeof == 0){
 #     call distancessplines(nz1,b,effet,mt,xTOut,lamTOut,suTOut)
    }else if(typeof == 1){
  #    Call distanceScpm(b,nbintervR*nst,mt,xTOut,lamTOut,xSuT,suTOut)
    }else if(typeof == 2){
      typeof2 = 1            
#      Call distanceSweib(b,np,mt,xTOut,lamTOut,xSuT,suTOut)         
    }
    resOut=res
    for(l in 1:nst){
      scaleweib[l] = etaT[l]
      shapeweib[l] = betaT[l]
    }
  
  
        #!AD:add LCV
        #!LCV(1) The approximate like cross-validation Criterion
        #!LCV(2) Akaike information Criterion
        #!     calcul de la trace, pour le LCV (likelihood cross validation)
    LCV <- 0
    if (typeof == 0){
#!        write(*,*)'The approximate like cross-validation Criterion in the non parametric case'
      HI <- H_hess%*%I_hess#call multis(H_hess,I_hess,np,np,np,HI)
      for(i in 1:np){
        LCV[1] = LCV[1] + HI[i,i]
      }
      LCV[1] = (LCV[1]-resnonpen) / nsujet
    }else{
#!        write(*,*)'=========> Akaike information Criterion <========='
      LCV[2] = (1 / nsujet) *(np - resOut)
    }

  
        HIHOut <- HIH[1:np,1:np]
        H_hessOut <- H_hess[1:np,1:np]
     
  
  #  !CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
  #!
  #!    Bias and Var eliminated
  #!
  #!CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
  #!AD:
  }
#  1000    continue
  

  
#  !---------------------Calcul residus de martingales
  
  
  coefBeta <- matrix(rep(0, nva), nrow = 1)
  Xbeta <- matrix(rep(0, nsujet), nrow = 1)
  
  if(timedep == 0){
    coefBeta[1,] = b[(np-nva+1):np]
    Xbeta = coefBeta%*%t(ve)
  }#else{
 #       for(j in 1:nsujet){
#          p=1
#  call splinebasisIndiv(qorder-1,nbinnerknots+2*qorder,nbinnerknots,nbinnerknots+qorder,t1(j), &
#  innerknots,boundaryknots,basis)
#  do i=1,nva
#  coefBeta2 = 0.d0
#  if (filtretps(i).eq.1) then
#  do k=-qorder+1,nbinnerknots
#  coefBeta2 = coefBeta2 + b(np-(nva+npbetatps)+p-1+k+qorder)*basis(k+qorder)
#  end do
#  else
#  coefBeta2 = b(np-(nva+npbetatps)+p)
#  endif
#  Xbeta(1,j) = Xbeta(1,j) + coefBeta2*dble(ve(j,i))
#  p=p+filtretps(i)*(nbinnerknots+qorder-1)+1
#  end do
#  enddo
 # endif
  if(typeof==0){
    if((istopp[1] == 0) && (istopp[2] == 0)){
      vecuiRes <- rep(0,ng)
      vres <- rep(0,(1*(1+3)/2) )
      I_hess <- matrix(0)
      H_hess <- matrix(0)
      post_esp <- rep(0, ng)
      post_SD <- rep(0, ng)
      effetres = effet
      if(effet == 1){
        
        #Call ResidusMartingale(b,np,funcpasres,Resmartingale,frailtypred,frailtyvar,frailtysd)
      }else{
        Resmartingale=0
        frailtypred=0
        frailtyvar=0
        frailtysd=0
      }
  
      for(i in 1:nsujet){
        if(effet == 1){
          if(logNormal == 0){
            linearpred[i] <- Xbeta[1,i]+log(frailtypred[g[i]])
          }else{
            linearpred[i]=Xbeta[1,i]+frailtypred[g[i]]
          }
        }else{
          linearpred[i]=Xbeta[1,i]
          martingaleCox[i] = c[i] - RisqCumul[i]
        }
      }
  
    }else{
      Resmartingale=0
      frailtypred=0
      linearpred=0
      martingaleCox=0
    }
  
  }else{
    if((istopp[2] == 0)){
      vecuiRes <- rep(0,ng)
      vres <- rep(0,(1*(1+3)/2) )
      I_hess <- matrix(0)
      H_hess <- matrix(0)
      post_esp <- rep(0, ng)
      post_SD <- rep(0, ng)
      effetres = effet
  
      if(effet == 1){
      #  Call ResidusMartingale(b,np,funcpasres,Resmartingale,frailtypred,frailtyvar,frailtysd)
      }else{
        Resmartingale=0
        frailtypred=0
        frailtyvar=0
        frailtysd=0
      }
  
      for(i in 1:nsujet){
        if(effet == 1){
          linearpred[i]=Xbeta[1,i]+log(frailtypred[g[i]])
        }else{
          linearpred[i]=Xbeta[1,i]
          martingaleCox[i] = c[i] - RisqCumul[i]
        }
      }
    }else{
      Resmartingale=0
      frailtypred=0
      linearpred=0
      martingaleCox=0
    }
  }

  frailtypack_list <- list(nsujet, ng, icen, nst, effet, 
                           nz, axT, tt0, tt1, ic, groupe, nva, str, vax, 
                           AG, noVar, maxiter, irep1, np, b, H_hessOut, HIHOut, resOut, LCV, 
                           xTOut, lamTOut, xSuT, suTOut, typeof, equidistant, nbintervR, mt,  
                           ni, cpt, ier, k0, ddl, istop, shapeweib, scaleweib, mt1, ziOut, Resmartingale, martingaleCox, 
                           frailtypred, frailtyvar, frailtysd, linearpred, time, intcens, ttU, logNormal,  
                           timedep, nbinnerknots, qorder, filtretps, BetaTpsMat, EPS)
  frailtypack_list
  
}# end frailtypack
  
  
  
  
 # !========================== VECSPLI ==============================
vecsplis <- function(n,ndate,date,zi,mm2,mm3,mm1,mm,im3,im2,im1,im){

  
 # !---------  calcul de u(ti) ---------------------------
    
  j<-0
  for(i in 1:(ndate-1)){
    for(k in 5:(n-2+4)){
      if((date[i] >= zi[k-1]) && (date[i] < zi[k]))j <- k-1
    } 
    ht <- date[i]-zi[j]
    htm<- date[i]-zi[j-1]
    h2t<- date[i]-zi[j+2]
    ht2 <- zi[j+1]-date[i]
    ht3 <- zi[j+3]-date[i]
    hht <- date[i]-zi[j-2]
    h <- zi[j+1]-zi[j]
    hh<- zi[j+1]-zi[j-1]
    h2<- zi[j+2]-zi[j]
    h3<- zi[j+3]-zi[j]
    h4<- zi[j+4]-zi[j]
    h3m<- zi[j+3]-zi[j-1]
    h2n<-zi[j+2]-zi[j-1]
    hn<- zi[j+1]-zi[j-2]
    hh3 <- zi[j+1]-zi[j-3]
    hh2 <- zi[j+2]-zi[j-2]
   
    mm3[i] <- ((4*ht2*ht2*ht2)/(h*hh*hn*hh3))
    mm2[i] <- ((4*hht*ht2*ht2)/(hh2*hh*h*hn))+((-4*h2t*htm*ht2)/(hh2*h2n*hh*h))+((4*h2t*h2t*ht)/(hh2*h2*h*h2n))
    mm1[i] <- (4*(htm*htm*ht2)/(h3m*h2n*hh*h))+((-4*htm*ht*h2t)/(h3m*h2*h*h2n))+((4*ht3*ht*ht)/(h3m*h3*h2*h))
    mm[i]  <- 4*(ht*ht*ht)/(h4*h3*h2*h)
    im3[i] <- (0.25*(date[i]-zi[j-3])*mm3[i])+(0.25*hh2 *mm2[i])+(0.25*h3m*mm1[i])+(0.25*h4*mm[i])
    im2[i] <- (0.25*hht*mm2[i])+(h3m*mm1[i]*0.25)+(h4*mm[i]*0.25)
    im1[i] <- (htm*mm1[i]*0.25)+(h4*mm[i]*0.25)
    im[i]  <- ht*mm[i]*0.25
  
  }
  vecsplis_list <- list(mm2,mm3,mm1,mm,im3,im2,im1,im)
}
  
 # !========================== VECPEN ==============================
vecpens <- function(n,zi,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m){
 
  for(i in 4:(n-3+4)){
  h <- zi[i+1]-zi[i]
  hh<- zi[i+1]-zi[i-1]
  h2<- zi[i+2]-zi[i]
  h3<- zi[i+3]-zi[i]
  h4<- zi[i+4]-zi[i]
  h3m<- zi[i+3]-zi[i-1]
  h2n<-zi[i+2]-zi[i-1]
  hn<- zi[i+1]-zi[i-2]
  hh3 <- zi[i+1]-zi[i-3]
  hh2 <- zi[i+2]-zi[i-2]
  a3 <- h*hh*hn*hh3
  a2 <- hh2*hh*h*hn
  b2 <- hh2*h2n*hh*h
  c2 <- hh2*h2*h*h2n
  a1 <- h3m*h2n*hh*h
  b1 <- h3m*h2*h*h2n
  c1 <- h3m*h3*h2*h
  a0 <- h4*h3*h2*h
  x3 <- zi[i+1]*zi[i+1]*zi[i+1]-zi[i]*zi[i]*zi[i]
  x2 <- zi[i+1]*zi[i+1]-zi[i]*zi[i]
  x  <- zi[i+1]-zi[i]
  
  m3m3[i-3] <- (192*h/(hh*hn*hh3*hh*hn*hh3))
  m2m2[i-3] <- 64*(((3*x3-(3*x2*(2*zi[i+1]+zi[i-2]))
                      +x*(4*zi[i+1]*zi[i+1]+zi[i-2]*zi[i-2]+4*zi[i+1]*zi[i-2]))/(a2*a2)))
  m2m2[i-3] <- m2m2[i-3] + 64*(((3*x3-(3*x2*(zi[i+2] 
              +zi[i-1]+zi[i+1]))+x*(zi[i+2]*zi[i+2]+zi[i-1]*zi[i-1] 
              +zi[i+1]*zi[i+1]+2*zi[i+2]*zi[i-1]+2*zi[i+2] 
               *zi[i+1]+2*zi[i-1]*zi[i+1]))/(b2*b2)))
  m2m2[i-3] <- m2m2[i-3] +64*((3*x3-(3*x2*(2*zi[i+2] 
             +zi[i]))+x*(4*zi[i+2]*zi[i+2]+zi[i]*zi[i]+4*zi[i+2] *zi[i]))/(c2*c2))
  m2m2[i-3] <- m2m2[i-3] +128*((3*x3-(1.5*x2*(zi[i+2] 
             +zi[i-1]+3*zi[i+1]+zi[i-2]))+x*(2*zi[i+1]*zi[i+2] 
               +2*zi[i+1]*zi[i-1]+2*zi[i+1]*zi[i+1]+zi[i-2]*zi[i+2] 
               +zi[i-2]*zi[i-1]+zi[i-2]*zi[i+1]))/(a2*b2))
  m2m2[i-3] <- m2m2[i-3] + 128*((3*x3-(1.5* 
             x2*(2*zi[i+2]+zi[i]+2*zi[i+1]+zi[i-2]))+x* 
              (4*zi[i+1]*zi[i+2]+2*zi[i+1]*zi[i]+2*zi[i-2] 
               *zi[i+2]+zi[i-2]*zi[i]))/(a2*c2))
  m2m2[i-3] <- m2m2[i-3] + 128*((3*x3-(1.5*x2 
            *(3*zi[i+2]+zi[i]+zi[i-1]+zi[i+1]))+x*(zi[i+2]*zi[i]+ 
             2*zi[i-1]*zi[i+2]+zi[i]*zi[i-1]+2*zi[i+1]*zi[i+2] 
             +zi[i+1]*zi[i]+2*zi[i+2]*zi[i+2]))/(b2*c2))
  m1m1[i-3] <- 64*((3*x3-(3*x2*(2*zi[i-1]+zi[i+1])) 
                    +x*(4*zi[i-1]*zi[i-1]+zi[i+1]*zi[i+1]+4*zi[i-1] 
                        *zi[i+1]))/(a1*a1))
  m1m1[i-3] <- m1m1[i-3] + 64*((3*x3-(3*x2*(zi[i-1]+zi[i] 
             +zi[i+2]))+x*(zi[i-1]*zi[i-1]+zi[i]*zi[i]+zi[i+2]* 
              zi[i+2]+2*zi[i-1]*zi[i]+2*zi[i-1]*zi[i+2]+2* 
              zi[i]*zi[i+2]))/(b1*b1))
  m1m1[i-3] <- m1m1[i-3] + 64*((3*x3-(3*x2*(zi[i+3] 
            +2*zi[i]))+x*(zi[i+3]*zi[i+3]+4*zi[i]*zi[i] 
             +4*zi[i+3]*zi[i]))/(c1*c1)) 
  m1m1[i-3] <- m1m1[i-3] + 128*((3*x3-(1.5*x2*(3 
              *zi[i-1]+zi[i]+zi[i+2]+zi[i+1]))+x*(2*zi[i-1]*zi[i-1] 
              +2*zi[i-1]*zi[i]+2*zi[i-1]*zi[i+2]+zi[i+1]*zi[i-1] 
              +zi[i+1]*zi[i]+zi[i+1]*zi[i+2]))/(a1*b1))
  m1m1[i-3] <- m1m1[i-3] + 128*((3*x3-(1.5*x2*(zi[i+3]+ 
                                                  2*zi[i]+2*zi[i-1]+zi[i+1]))+x*(2*zi[i-1]*zi[i+3] 
                                                                                       +4*zi[i-1]*zi[i]+zi[i+1]*zi[i+3]+2*zi[i+1]*zi[i])) 
                              /(a1*c1))    
  m1m1[i-3] <- m1m1[i-3] + 128*((3*x3-(1.5*x2*(zi[i+3]+3 
                                                  *zi[i]+zi[i-1]+zi[i+2]))+x*(zi[i-1]*zi[i+3]+2*zi[i-1] 
                                                    *zi[i]+zi[i+3]*zi[i]+2*zi[i]*zi[i]+zi[i+2]*zi[i+3] 
                                                                              +2*zi[i+2]*zi[i]))/(b1*c1))
  mmm[i-3] <- (192*h/(h4*h3*h2*h4*h3*h2))
  m3m2[i-3] <- 192*(((-x3+(0.5*x2*(5*zi[i+1]+zi[i-2] 
  ))-x*(2*zi[i+1]*zi[i+1]+zi[i+1]*zi[i-2]))/(a3*a2)) 
  +((-x3+(0.5*x2*(4*zi[i+1]+zi[i-1]+zi[i+2]))-x* 
     (zi[i+1]*zi[i+2]+zi[i+1]*zi[i-1]+zi[i+1]*zi[i+1]))/(a3*b2)) 
  +((-x3+(0.5*x2*(3*zi[i+1]+2*zi[i+2]+zi[i]))-x* 
     (2*zi[i+1]*zi[i+2]+zi[i+1]*zi[i]))/(a3*c2)))
  m3m1[i-3] <- 192*(((x3-(0.5*x2*(4*zi[i+1]+2*zi[i-1] 
  ))+x*(2*zi[i+1]*zi[i-1]+zi[i+1]*zi[i+1]))/(a3*a1)) 
  +((x3-(0.5*x2*(3*zi[i+1]+zi[i+2]+zi[i-1]+zi[i])) 
     +x*(zi[i+1]*zi[i-1]+zi[i+1]*zi[i]+zi[i+1]*zi[i+2]))/(b1*a3)) 
  +((x3-(0.5*x2*(3*zi[i+1]+zi[i+3]+2*zi[i]))+x*(zi[i+1] 
  *zi[i+3]+2*zi[i+1]*zi[i]))/(c1*a3)) )
  m3m[i-3] <- 576*((-(x3/3)+(0.5*x2*(zi[i+1]+zi[i])) 
                    -x*zi[i+1]*zi[i])/(a3*a0))
  m2m1[i-3] <- 64*((-3*x3+(1.5*x2*(2*zi[i-1]+3* 
                                        zi[i+1]+zi[i-2]))-x*(4*zi[i+1]*zi[i-1]+2*zi[i+1] 
                                                             *zi[i+1]+2*zi[i-2]*zi[i-1]+zi[i-2]*zi[i+1]))/(a2*a1)) 
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(zi[i-1]+ 
             zi[i]+zi[i+2]+2*zi[i+1]+zi[i-2]))-x*(2*zi[i+1]*zi[i-1] 
            +2*zi[i+1]*zi[i]+2*zi[i+1]*zi[i+2]+zi[i-2]*zi[i-1]+ 
             zi[i-2]*zi[i]+zi[i-2]*zi[i+2]))/(a2*b1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(zi[i+3]+2 
             *zi[i]+2*zi[i+1]+zi[i-2]))-x*(2*zi[i+1]*zi[i+3]+4 
             *zi[i+1]*zi[i]+zi[i-2]*zi[i+3]+2*zi[i-2]*zi[i]))/(a2*c1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2* 
              (3*zi[i-1]+2*zi[i+1]+zi[i+2]))-x*(2*zi[i+2]*zi[i-1] 
             +zi[i+2]*zi[i+1]+2*zi[i-1]*zi[i-1]+3 
              *zi[i+1]*zi[i-1]+zi[i+1]*zi[i+1]))/(b2*a1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(2 
             *zi[i-1]+zi[i]+2*zi[i+2]+zi[i+1]))-x*(zi[i+2]*zi[i-1] 
             +zi[i+2]*zi[i]+zi[i+2]*zi[i+2]+zi[i-1]*zi[i-1]+zi[i-1] 
              *zi[i]+zi[i-1]*zi[i+2]+zi[i+1]*zi[i-1]+zi[i+1]*zi[i] 
              +zi[i+1]*zi[i+2]))/(b2*b1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(zi[i+3] 
             +2*zi[i]+zi[i+2]+zi[i-1]+zi[i+1]))-x*(zi[i+2]*zi[i+3] 
             +2*zi[i+2]*zi[i]+zi[i-1]*zi[i+3]+2*zi[i-1]*zi[i] 
              +zi[i+1]*zi[i+3]+2*zi[i+1]*zi[i]))/(b2*c1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(2*zi[i-1] 
             +zi[i+1]+2*zi[i+2]+zi[i]))-x*(4*zi[i+2]*zi[i-1]+2* 
              zi[i+2]*zi[i+1]+2*zi[i]*zi[i-1]+zi[i]*zi[i+1]))/(c2*a1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(zi[i-1] 
              +2*zi[i]+3*zi[i+2]))-x*(2*zi[i+2]*zi[i-1]+2 
           *zi[i+2]*zi[i]+2*zi[i+2]*zi[i+2]+zi[i]*zi[i-1]+zi[i] 
                 *zi[i]+zi[i]*zi[i+2]))/(c2*b1))
  m2m1[i-3] <- m2m1[i-3] + 64*((-3*x3+(1.5*x2*(zi[i+3] 
           +3*zi[i]+2*zi[i+2]))-x*(2*zi[i+2]*zi[i+3]+4 
            *zi[i+2]*zi[i]+zi[i]*zi[i+3]+2*zi[i]*zi[i]))/(c2*c1))
  m2m[i-3] <- 192*(((x3-(0.5*x2*(3*zi[i]+2*zi[i+1] 
                                   +zi[i-2]))+x*(2*zi[i+1]*zi[i]+zi[i-2]*zi[i]))/(a2*a0)) 
                   +((x3-(0.5*x2*(3*zi[i]+zi[i+2]+zi[i-1]+zi[i+1])) 
                      +x*(zi[i+2]*zi[i]+zi[i-1]*zi[i]+zi[i+1]*zi[i]))/(b2*a0)) 
                   +((x3-(0.5*x2*(4*zi[i]+2*zi[i+2]))+x*(2*zi[i+2] 
                                                                 *zi[i]+zi[i]*zi[i]))/(c2*a0)) )
  m1m[i-3] <- 192*(((-x3+(0.5*x2*(3*zi[i]+2*zi[i-1] 
                                    +zi[i+1]))-x*(2*zi[i-1]*zi[i]+zi[i+1]*zi[i]))/(a1*a0)) 
                   +((-x3+(0.5*x2*(4*zi[i]+zi[i-1]+zi[i+2])) 
                      -x*(zi[i-1]*zi[i]+zi[i]*zi[i]+zi[i+2]*zi[i]))/(b1*a0)) 
                   +((-x3+(0.5*x2*(5*zi[i]+zi[i+3]))-x*(zi[i+3]*zi[i] 
                                                             +2*zi[i]*zi[i]))/(c1*a0)))
  
  }
  vecpens_list <- list(m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m)
  }
  
  
 # !========================          ESTIMV         ===================
    
estimvs <- function(k00,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                    im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                    m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                    model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                    nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat){


  y <- matrix(rep(0, np^2), nrow = np)
  v <- rep(0, np*(np+3)/2)
  the <- rep(0, np+3)
  k0 <- rep(0, 2)
  ut <- rep(0, ndate)
  dut <- rep(0, ndate)
  bh <- rep(0, np)
  j <- 0
  estimvs <- 0
  k0T[1] <-  k00*k00 #!en plus strates A.Lafourcade 05/2014
  k0[1] <- k00*k00
  k0[2] <- 0

 
  ca = 0
  cb = 0
  dd = 0
  ni = 0
  ier = 0
  istop  = 0
  vvv <- rep(0,(np*(np+1)/2))
  if(logNormal == 0){
    if(intcens == 1){
    #  call marq98j(k0,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_intcens)
    }else{
      marq98j_list <- marq98j(k0,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines,nva,
                              model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                              m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                              mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                              nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                              ndatemax,memb,Kmat)
      b <- marq98j_list[[1]]
      ni <- marq98j_list[[2]]
      v <- marq98j_list[[3]]
      res <- marq98j_list[[4]]
      ier <- marq98j_list[[5]]
      istop <- marq98j_list[[6]]
      I_hess <- marq98j_list[[7]]
      H_hess <- marq98j_list[[8]]
      hess <- marq98j_list[[9]]
      vvv <- marq98j_list[[10]]
      epsa <- marq98j_list[[11]]
      epsb <- marq98j_list[[12]]
      epsd <- marq98j_list[[13]]
      pe <- marq98j_list[[14]]
      resnonpen <- marq98j_list[[15]]
    }
  }else{
 #   call marq98j(k0,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_log)
    marq98j_list <- marq98j(k0,b,n,ni,v,res,ier,istop,effet,ca,cb,dd,funcpassplines_log,nva,
                            model,I_hess,H_hess,hess,indic_alpha,typeof,vvv,epsa,epsb,epsd,maxiter,
                            m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                            mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,ndate, 
                            nst,stra,ve,pe,ng,g,nig,AG,resnonpen,theta,k0T,np,
                            ndatemax,memb,Kmat)
    b <- marq98j_list[[1]]
    ni <- marq98j_list[[2]]
    v <- marq98j_list[[3]]
    res <- marq98j_list[[4]]
    ier <- marq98j_list[[5]]
    istop <- marq98j_list[[6]]
    I_hess <- marq98j_list[[7]]
    H_hess <- marq98j_list[[8]]
    hess <- marq98j_list[[9]]
    vvv <- marq98j_list[[10]]
    epsa <- marq98j_list[[11]]
    epsb <- marq98j_list[[12]]
    epsd <- marq98j_list[[13]]
    pe <- marq98j_list[[14]]
    resnonpen <- marq98j_list[[15]]
  }
  if (istop != 4){
    if(k0[1] > 0){
      for(ij in 1:n){
        the[ij] <- b[ij]*b[ij]
        bh[ij] <- b[ij]*b[ij]
      }
     vj <- 4
      som <- 0
      dut[1] <- (the[1]*4/(zi[5]-zi[4]))
      ut[1] <- the[1]*dut[1]*0.25*(zi[4]-zi[1])
      for(i in 2:(ndate-1)){
        for(k in 5:(n-2+4)){
          if(date[i] >= zi[k-1] && date[i]<zi[k]){
            j <- k-1
            if(j>4 && j>vj){
              som <- som+the[j-4]
              vj  <- j
            }
          }
        }
        ut[i] <- som +(the[j-3]*im3[i])+(the[j-2]*im2[i])+(the[j-1]*im1[i])+(the[j]*im[i])
        dut[i] <- (the[j-3]*mm3[i])+(the[j-2]*mm2[i])+(the[j-1]*mm1[i])+(the[j]*mm[i])
     }
      
      i <- n-2
      h1 <- (zi[i+3]-zi[i+2])
      ut[ndate] <- som+ the[i-1] + the[i]+the[i+1]+the[i+2]
      dut[ndate] <- (4*the[i+2]/h1)
 
    aux <- tests(dut,k0,n,aux,y, np,ndate,date,zi,c,nt1,nsujet,ndatemax,
                          m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm)

      estimvs <- -(res-pe) - aux
    }else{
      aux <- -n
    }
  }
 
  estimvs_list <- list(estimvs,k00,n,b,y,aux,ni,res)
 

  estimvs_list
}
  
  
  
  
#  !=================calcul de la hessienne  et de omega  ==============
tests <- function(dut,k0,n,res,y, np,ndate,date,zi,c,nt1,nsujet,ndatemax,
                  m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm){
  
  hessh <- matrix(rep(0, np^2), nrow = np)
  hess <- matrix(rep(0, np^2), nrow = np)
  omeg <- matrix(rep(0, np^2), nrow = np)
  y <- matrix(rep(0, np^2), nrow = np)
  indx <- rep(0, np)
 
  
  
  for(i in 4:(n+3)){
    for(j in i:(n+3)){
      hess[i-3,j-3] <- mats(hess[i-3,j-3],dut,i,j,n,date,zi,c,nt1,nsujet,ndate,np,ndatemax)
    }
  }
  for(i in 2:n){
    for(j in 1:(i-1)){
      hess[i,j] <- hess[j,i]
    }
  }

  omeg <- calcomegs(n,omeg,np,m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm)

  for(i in 1:n){
    for(j in 1:n){
      hessh[i,j] <- -hess[i,j]
      hess[i,j] <- hess[i,j] - (2*k0[1]*omeg[i,j])
    }
  }
  
  np <- n
  for(i in 1:n){
    for(j in 1:n){
      y[i,j] <- 0
    }
    y[i,i] <- 1
  }

  ludcmps_list <- ludcmps(hess,n,indx,d) #decomposition LU
  hess <- ludcmps_list[[1]]
  indx <- ludcmps_list[[2]]
  d <- ludcmps_list[[3]]

    for(j in 1:n){
    y[,j] <- lubksbs(hess,n,indx,y[,j],np) #! resolution AX=B
  
  }

  tra <- 0
  for(i in 1:n){
    for(j in 1:n){
      tra <- tra + y[i,j]*hessh[j,i]
    }
  }
  
  res <- tra
  res
}
  
  
#  !====================  MAT  ==================================
mats <- function(res,dut,k,l,n,date,zi,c,nt1,nsujet,ndate,np,ndatemax){
  
#  dut <- rep(0, ndate)
#  !--------- calcul de la hessienne ij ------------------

  res <- 0
  res1 <- 0
  for(i in 1:nsujet){
    if(c[i] == 1){# !event
      u2 <- dut[nt1[i]]
      for(j in 5:(n-2+3)){
        if((date[nt1[i]] >= zi[j-1]) && (date[nt1[i]] < zi[j])){
          ni <- j-1
        }
      }
      if(date[nt1[i]] == zi[n-2+3]){
   #     print(paste("tutaj",nt1[i],zi[n-2+3],n))
        ni <- n-2+3
      }
  #!------attention numero spline
      aux2 <- msps(nt1[i],ni,k,np,ndatemax,date,zi)*msps(nt1[i],ni,l,np,ndatemax,date,zi)
  #  print(paste("aux2",k,l,i,aux2,nt1[i],ni,n))
 
      if(u2 < 0){
        res1 <- 0
      }else{
        res1 <- - aux2/(u2*u2)
      }
    }else{ #!censure
      res1 <- 0
    }
  
  res <- res + res1  
  }
  res
}
  
 # !=======================  CALOMEG  ===========================
calcomegs <- function(n,omeg, np,m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm){

  omeg <- matrix(rep(0, np^2), nrow = np)
  
  omeg[1,1] <- calc00s(1,n,m3m3,m2m2,m1m1,mmm)
  omeg[1,2] <- calc01s(1,n,m3m2,m2m1,m1m)
  omeg[1,3] <- calc02s(1,n, m3m1,m2m)
  omeg[1,4] <- m3m[1]
  omeg[2,1] <- omeg[1,2]
  omeg[2,2] <- calc00s(2,n,m3m3,m2m2,m1m1,mmm)
  omeg[2,3] <- calc01s(2,n,m3m2,m2m1,m1m)
  omeg[2,4] <- calc02s(2,n, m3m1,m2m)
  omeg[2,5] <- m3m[2]
  omeg[3,1] <- omeg[1,3]
  omeg[3,2] <- omeg[2,3]
  omeg[3,3] <- calc00s(3,n,m3m3,m2m2,m1m1,mmm)
  omeg[3,4] <- calc01s(3,n,m3m2,m2m1,m1m)
  omeg[3,5] <- calc02s(3,n, m3m1,m2m)
  omeg[3,6] <- m3m[3]
  
  for(i in 4:(n-3)){
  omeg[i,i-3] <- omeg[i-3,i]
  omeg[i,i-2] <- omeg[i-2,i]
  omeg[i,i-1] <- omeg[i-1,i]
  omeg[i,i] <- calc00s(i,n,m3m3,m2m2,m1m1,mmm)
  omeg[i,i+1] <- calc01s(i,n,m3m2,m2m1,m1m)
  omeg[i,i+2] <- calc02s(i,n, m3m1,m2m)
  omeg[i,i+3] <- m3m[i]
  }
  
  omeg[n-2,n-5] <- omeg[n-5,n-2]
  omeg[n-2,n-4] <- omeg[n-4,n-2]
  omeg[n-2,n-3] <- omeg[n-3,n-2]
  omeg[n-2,n-2] <- calc00s(n-2,n,m3m3,m2m2,m1m1,mmm)
  omeg[n-2,n-1] <- calc01s(n-2,n,m3m2,m2m1,m1m)
  omeg[n-2,n] <- calc02s(n-2,n, m3m1,m2m)
  omeg[n-1,n-4] <- omeg[n-4,n-1]
  omeg[n-1,n-3] <- omeg[n-3,n-1]
  omeg[n-1,n-2] <- omeg[n-2,n-1]
  omeg[n-1,n-1] <- calc00s(n-1,n,m3m3,m2m2,m1m1,mmm)
  omeg[n-1,n] <- calc01s(n-1,n,m3m2,m2m1,m1m)
  omeg[n,n-3] <- omeg[n-3,n]
  omeg[n,n-2] <- omeg[n-2,n]
  omeg[n,n-1] <- omeg[n-1,n]
  omeg[n,n] <- calc00s(n,n,m3m3,m2m2,m1m1,mmm)
  
  omeg
}
  
  
#  !======================  LUBKSB  ======================================
lubksbs <- function(a,n,indx,b,np){
  
 # indx <- rep(0, np)
  #a <- matrix(rep(0, np^2), nrow = np)
  #b <- rep(0, np)

  ii <- 0
  for(i in 1:n){
    ll <- indx[i]
    sum <- b[ll]
    b[ll] <- b[i]
   # print(paste(i,ll,ii,b[i]))
    if(ii != 0){
      for(j in ii:(i-1)){
        sum = sum -a[i,j]*b[j]
      }
    }else{
      if(sum != 0)ii <- i
    }
    b[i] <- sum
  }

  for(i in n:1){
    sum <- b[i]
    if(i+1 <= n){
    for(j in (i+1):n){
      sum <- sum-a[i,j]*b[j]
    }}
    b[i] <- sum/a[i,i]
  }
  
  b
}
  

#!======================  LUDCMP  ======================================
ludcmps <- function(a,n,indx,d, np){
  
  nmax <- 500
  tiny <- 1e-20
  vv <- rep(0, nmax)
  
  imax <- 0
  d <- 1
  for(i in 1:n){
    aamax <- 0
    for(j in 1:n){
     
      if(abs(a[i,j]) > aamax)aamax <- abs(a[i,j])
    }
    vv[i] <- 1/aamax
  }
  
  for(j in 1:n){
    if(j >=2){
      for(i in 1:(j-1)){
        sum <- a[i,j]
        if(j >=3 && i>=2){
          for(k in 1:(i-1)){
        #    print(paste(j,i,k,sum,n))
            sum <- sum - a[i,k]*a[k,j]
          }
      #    print(sum)
        }
        a[i,j] <- sum
      }
    }
    aamax <- 0
    for(i in j:n){
      sum <- a[i,j]
      if(j >= 2){
        for(k in 1:(j-1)){
          sum <- sum -a[i,k]*a[k,j]
        }
      }
      a[i,j] = sum
      dum = vv[i]*abs(sum)
      if(dum >= aamax){
        imax = i
        aamax = dum
      }
    }
    if(j != imax){
      for(k in 1:n){
        dum <- a[imax,k]
        a[imax,k] <- a[j,k]
    #    print(paste(j,k,imax,n))
        a[j,k] <- dum
      }
      d <- -d
      vv[imax] <- vv[j]
    }
    indx[j] <- imax
    if(a[j,j] == 0)a[j,j] <- tiny

    if(j != n){
      dum = 1/a[j,j]
      for(i in (j+1):n){
        a[i,j] <- a[i,j]*dum
      }
    }
  }    

  ludcmps_list <- list(a, indx, d)
  ludcmps_list
}
 
#  !==========================  MSP   ==================================
msps <- function(i,ni,ns,np,ndatemax,date,zi){
 #print(paste("ni",ni,"ns",ns))
  if(ni < ns-3){
    val <- 0
  }else{
    if(ns-3 == ni){
   #   if(i==60)print(paste("heeeeeer",date[i],zi[ni]))
      if(date[i] == zi[ni]){
        val <- 0
      }else{  
        val <- (4*(date[i]-zi[ni])*(date[i]-zi[ni]) 
           *(date[i]-zi[ni]))/((zi[ni+4]-zi[ni])*(zi[ni+3] 
          -zi[ni])*(zi[ni+2]-zi[ni])*(zi[ni+1]-zi[ni]))
      }
    }else{
      if(ns-2 == ni){
        if(date[i] == zi[ni]){
          val <- (4*(zi[ni]-zi[ni-1])*(zi[ni]-zi[ni-1]))/((zi[ni+3]-zi[ni-1])*(zi[ni+2]-zi[ni-1])*(zi[ni+1]-zi[ni-1]))
        }else{  
          val = (4*(date[i]-zi[ni-1])*(date[i]-zi[ni-1]) 
             *(zi[ni+1]-date[i]))/((zi[ni+3]-zi[ni-1])*(zi[ni+2]
              -zi[ni-1])*(zi[ni+1]-zi[ni-1])*(zi[ni+1]-zi[ni]))+(4*(date[i]-zi[ni-1])*(date[i]-zi[ni]) 
            *(zi[ni+2]-date[i]))/((zi[ni+3]-zi[ni-1])*(zi[ni+2] 
            -zi[ni])*(zi[ni+1]-zi[ni])*(zi[ni+2]-zi[ni-1]))+(4*(date[i]-zi[ni])*(date[i]-zi[ni]) 
            *(zi[ni+3]-date[i]))/((zi[ni+3]-zi[ni-1])*(zi[ni+3] 
            -zi[ni])*(zi[ni+2]-zi[ni])*(zi[ni+1]-zi[ni]))
        }
      }else{
        if(ns-1== ni){
          
          if(date[i] == zi[ni]){
            val <- (4*((zi[ni]-zi[ni-2])*(zi[ni+1] 
              -zi[ni]))/((zi[ni+2]-zi[ni-2])*(zi[ni+1] 
              -zi[ni-1])*(zi[ni+1]-zi[ni-2])))+((4*((zi[ni]-zi[ni-1])*(zi[ni+2]-zi[ni]))  
              /((zi[ni+2]-zi[ni-2])*(zi[ni+2]-zi[ni-1]) 
              *(zi[ni+1]-zi[ni-1]))))
          }else{
            val = (4*((date[i]-zi[ni-2])*(zi[ni+1] 
              -date[i])*(zi[ni+1]-date[i]))/((zi[ni+2] 
              -zi[ni-2])*(zi[ni+1]-zi[ni-1])*(zi[ni+1]- 
              zi[ni])*(zi[ni+1]-zi[ni-2]))) +((4*((date[i]-zi[ni-1])*(zi[ni+2]-date[i]) 
              *(zi[ni+1]-date[i]))/((zi[ni+2]-zi[ni-2]) 
              *(zi[ni+2]-zi[ni-1])*(zi[ni+1]-zi[ni-1])* 
              (zi[ni+1]-zi[ni])))) +((4*((zi[ni+2]-date[i])*(zi[ni+2]-date[i]) 
              *(date[i]-zi[ni]))/((zi[ni+2]-zi[ni-2])
              *(zi[ni+2]-zi[ni])*(zi[ni+2]-zi[ni-1])* 
              (zi[ni+1]-zi[ni]))))
            
          }
        }else{
          if(ni == ns){
           
            if(date[i] == zi[ni]){
              val =(4*(date[i]-zi[ni+1])*(date[i] 
                -zi[ni+1])/((zi[ni+1]-zi[ni-1])*(zi[ni+1] 
                -zi[ni-2])*(zi[ni+1]-zi[ni-3])))
            }else{
              val =(4*(date[i]-zi[ni+1])*(date[i] 
                -zi[ni+1])*(zi[ni+1]-date[i])/((zi[ni+1] 
                -zi[ni-1])*(zi[ni+1]-zi[ni-2])*(zi[ni+1] 
                -zi[ni])*(zi[ni+1]-zi[ni-3])))
            }
      #      print(paste("here",date[i],zi[ni],val))
          }else{
            val = 0
          }
        }
      }
    }
  }

 val
}
  
  
  
#  !=========================  CALC00  =========================
calc00s <- function(j,n,m3m3,m2m2,m1m1,mmm){
  
  if(j == 1){
    part = m3m3[j]
  }else{
    if(j == 2){
      part = m3m3[j] + m2m2[j-1]
    }else{
      if(j == 3){
        part = m3m3[j] + m2m2[j-1] + m1m1[j-2]
      }else{
        if(j == n-2){
          part = m2m2[j-1] + m1m1[j-2] + mmm[j-3]
        }else{   
          if(j == n-1){
            part = mmm[j-3] + m1m1[j-2]
          }else{
            if(j == n){
              part = mmm[j-3]
            }else{
              part=mmm[j-3]+m1m1[j-2]+m2m2[j-1]+m3m3[j]
            }
          }
        }
      }
    }
  }
  
  part
  
}
  
 # !=========================  CALC01  =========================
  
calc01s <- function(j,n,m3m2,m2m1,m1m){
  
  if(j == 1){
    part = m3m2[j]
  }else{
    if(j == 2){
      part = m3m2[j] + m2m1[j-1]
    }else{
      if(j == n-2){
      part = m1m[j-2] + m2m1[j-1]
      }else{
        if(j != n-1){
          part = m3m2[j] + m2m1[j-1] + m1m[j-2]
        }else{
          part = m1m[j-2]
        }
      }
    }
  }
  part
}
  
 # !=========================  CALC02  =========================
calc02s <- function(j,n, m3m1,m2m){

  if(j == 1){
    part = m3m1[j]
  }else{
    if(j != n-2){
      part = m3m1[j] + m2m[j-1]
    }else{
      part = m2m[j-1]
    }
  }
  part
  
}
  
#  !========================          MNBRAK         ===================
mnbraks <- function(ax,bx,cx,fa,fb,fc,b,n,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                    im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                    m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                    model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                    nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat){
  
  b <- rep(0, np)
  y <- matrix(rep(0, np^2), nrow = np)
  gold <- 1.618034
  glimit <- 100
  tiny <- 1e-20
  aux <- 0
  ni <- 0 
  res <- 0
  fa <- estimvs(ax,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
  fb <- estimvs(bx,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
               im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
               m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
               model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
               nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
  
  if(fb > fa){
    dum = ax
    ax = bx
    bx = dum
    dum = fb
    fb = fa
    fa = dum
  }
  
  cx = bx + gold*(bx-ax)
  fc = estimvs(cx,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
               im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
               m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
               model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
               nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
  
        
  while(fb >= fc){
    r = (bx-ax)*(fb-fc)
    q = (bx-cx)*(fb-fa)
    u = bx-((bx-cx)*q-(bx-ax)*r)/(2*max(abs(q-r),tiny)*sign(q-r))
    ulim = bx + glimit*(cx-bx)
  
    if((bx-u)*(u-cx) > 0){
      fu = estimvs(u,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
               im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
               m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
               model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
               nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
      if(fu < fc){
        ax = bx
        fa = fb
        bx = u
        fb = fu
        mnbraks_list <- list(ax, bx, cx, fa, fb, fc)
        mnbraks_list
        break
      }else{
        if(fu > fb){
          cx = u
          fc = fu
          mnbraks_list <- list(ax, bx, cx, fa, fb, fc)
          mnbraks_list
          break
        }
      }
    u = cx + gold*(cx-bx)
    fu = estimvs(u,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                   im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                   m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                 model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                 nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
  
    }else{
      if((cx-u)*(u-ulim) > 0){
        fu = estimvs(u,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
        if(fu < fc){
          bx = cx
          cx = u
          u = cx + gold*(cx-bx)
          fb = fc
          fc = fu
          fu = estimvs(u,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
        }
      }else{
        if((u-ulim)*(ulim-cx) >= 0){
          u = ulim
          fu = estimvs(u,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
        }else{
          u = cx + gold*(cx-bx)
          fu = estimvs(u,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                     im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                     m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                     model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                     nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
        }
      }
    }
    ax = bx
    bx = cx
    cx = u
    fa = fb
    fb = fc
    fc = fu
  }
  
  mnbraks_list <- list(ax, bx, cx, fa, fb, fc)
  mnbraks_list
  
  
}

#!========================      GOLDEN   =========================
goldens <- function(ax,bx,cx,tol,xmin,n,b,y,aux,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                    im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                    m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                    model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,
                    nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat){


  y <- matrix(rep(0, np^2), nrow = np)
  b <- rep(0, np)
  r <- 0.61803399
  c <- 1-r
  ni <- 0
  res <- 0
  x0 = ax
  x3 = cx
  if(abs(cx-bx) > abs(bx-ax)){
    x1 = bx
    x2 = bx + c*(cx-bx)
  }else{
    x2 = bx
    x1 = bx - c*(bx-ax)
  }

  f1 = estimvs(x1,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
               im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
               m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
               model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,nva,
               nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
  f2 = estimvs(x2,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
               im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
               m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
               model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,nva,
               nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)

  while(abs(x3-x0) > tol*(abs(x1)+abs(x2))){
    if(f2 < f1){
      x0 = x1
      x1 = x2
      x2 = r*x1 + c*x3
      f1 = f2
      f2 = estimvs(x2,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                   im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                   m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                   model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,nva,
                   nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
    }else{
      x3 = x2
      x2 = x1
      x1 = r*x2+c*x0
      f2 = f1
      f1 = estimvs(x1,n,b,y,aux,ni,res,ndate,k0T,date,zi,pe,effet,mm3,mm2,mm1,mm,im3,
                   im2,im1,im,intcens,logNormal,np,c,nt1,nsujet,ndatemax,
                   m3m,m3m1,m2m,m3m2,m2m1,m1m,m3m3,m2m2,m1m1,mmm,nva,
                   model,I_hess,H_hess,hess,indic_alpha,typeof,epsa,epsb,epsd,maxiter,nva,
                   nt0, nst,stra,ve,ng,g,nig,AG,resnonpen,theta,memb,Kmat)
    }
  }
  
  if(f1 < f2){
    goldens = f1
    xmin = x1
  }else{
    goldens = f2
    xmin = x2
  }

  goldens
}