
"slope"<-function(x)
 {
  x
 }
