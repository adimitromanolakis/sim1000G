

#! <-  <-  <  FUNCPA_SPLINES           <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <-  <- 
funcpassplines <- function(b,np,id,thi,jd,thj,k0,m3m3,m2m2,m1m1,mmm,m3m2,m3m1,m3m,m2m1,m2m,m1m, 
                             mm3,mm2,mm1,mm,im3,im2,im1,im,date,zi,c,nt0,nt1,nsujet,nva,ndate, 
                             nst,stra,ve,pe,effet,ng,g,nig,AG,resnonpen,theta,k0T,
                           ndatemax){

  funcpassplines <- 0
  cpt <- rep(0, ng)
  peT <- rep(0, nst)
  somT <- rep(0, nst)
  theT <- matrix(rep(0, (np+3)*nst), nrow  = np+3)
  bh <- rep(0, np)
  res1 <- rep(0, ng)
  res2 <- rep(0, ng)
  res3 <- rep(0, ng)
  dutT <- matrix(rep(0, ndatemax*nst), nrow = ndatemax)
  utT <- matrix(rep(0, (ndatemax+1)*nst), nrow  =  ndatemax+1)
 
  j <- 0
  theta <- 0
  bh[1:np] <- b[1:np]
  
  

  if(id != 0) bh[id] <- bh[id]+thi
  if(jd != 0) bh[jd] <- bh[jd]+thj

  n  <-  (np-nva-effet)/nst
  for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
    for(i in 1:n){
      theT[i,jj] <- (bh[(jj-1)*n+i])*(bh[(jj-1)*n+i])
    }
  }
  
#print(theT)
  if(effet == 1)theta  <-  bh[np-nva]*bh[np-nva]


#!---------  calcul de ut1(ti) et ut2(ti) ---------------------------
#  !    attention the(1)  sont en nz <- 1
#!        donc en ti on a the(i)

  vj  <-  4
  somT <- 0 #!en plus

  for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
    dutT[1,jj]  <-  (theT[1,jj]*4/(zi[5]-zi[4]))
    utT[1,jj]  <-  0
    utT[2,jj]  <-  theT[1,jj]*dutT[1,jj]*0.25*(zi[4]-zi[1])
  }
  

  for(i in 2:(ndate-1)){
    for(k in 5:(n-2+4)){
      if((date[i] >= zi[k-1]) && (date[i] < zi[k])){
        j  <-  k-1
 #       print(paste(j,k,date[i],zi[k-1],zi[k],vj))
        if((j > 4) && (j > vj)){
          for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
            somT[jj]  <-  somT[jj]+theT[j-4,jj]
          }
          vj   <-  j
        }
      }
    }
    for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
        utT[i+1,jj]  <-  somT[jj] +(theT[j-3,jj]*im3[i])+(theT[j-2,jj]*im2[i])+(theT[j-1,jj]*im1[i])+(theT[j,jj]*im[i])
      dutT[i,jj]  <-  (theT[j-3,jj]*mm3[i])+(theT[j-2,jj]*mm2[i])+(theT[j-1,jj]*mm1[i])+(theT[j,jj]*mm[i])
#print(paste(i,j,utT[i+1,jj],dutT[i,jj]))
 
    }
  }
  i  <-  n-2
  h1  <-  (zi[i+3]-zi[i+2])
#  print(h1)
  for(jj in 1:nst){
    utT[ndate+1,jj] <- somT[jj]+theT[i-1,jj]+theT[i,jj]+theT[i+1,jj]+theT[i+2,jj]
    dutT[ndate,jj]  <-  (4*theT[i+2,jj]/h1)
  }
#print(utT[ndate+1,jj])
#print(dutT[ndate,jj])
#!-------------------------------------------------------
#  !--------- calcul de la vraisemblance ------------------
#!--------------------------------------------------------
  
#  !--- avec ou sans variable explicative  ------cc

#!*******************************************
#  !---- sans effet aleatoire dans le modele
#!*******************************************
  if (effet == 0){
    for(i in 1:nsujet){
      cpt[g[i]] <- cpt[g[i]]+1

      if(nva > 0){
        vet  <-  0
        for(j in 1:nva){
          vet  <- vet + bh[np-nva+j]*ve[i,j]
        }
        vet  <-  exp(vet)
      }else{
        vet <- 1
      }

      if(c[i] == 1){
        res2[g[i]]  <-  res2[g[i]]+log(dutT[nt1[i],stra[i]]*vet)
   #     print(nt1[i])
 #       print(paste(i,g[i],res2[g[i]],nt1[i],dutT[nt1[i],stra[i]],vet))
 #             break
      }
      if(abs(res2[g[i]]) >= 1e+30){
        funcpassplines <- -1e+9
#go to 123
        break
      }

      res1[g[i]]  <-  res1[g[i]] + utT[nt1[i]+1,stra[i]]*vet-utT[nt0[i]+1,stra[i]]*vet
 #     RisqCumul[i]  <-  utT[nt1[i]+1,stra[i]]*vet

      if(abs(res1[g[i]]) >= 1e+30){
        funcpassplines <- -1e+9
#goto 123
        break
      }
    }
    if(funcpassplines != -1e+9){
      res  <-  0
      cptg  <-  0

      #! k indice les groupes
      for(k in 1:ng){
        if(cpt[k] > 0){
          nb  <-  nig[k]
          res  <-  res-res1[k]+res2[k]
          cptg  <-  cptg + 1
   #       print(paste(k,res,res1[k],res2[k],nt1[k]))
          if(abs(res) >= 1e+30){
            funcpassplines <- -1e+9
#goto 123
            break
          }
        }
      }
    }
    

#!*********************************************
#  !----avec un effet aleatoire dans le modele
#!*********************************************
  
  }else{
    inv  <-  1/theta
    for(i in 1:nsujet){
      cpt[g[i]] <- cpt[g[i]]+1
      if(nva > 0){
        vet  <-  0
        for(j in 1:nva){
          vet  <- vet + bh[np-nva+j]*ve[i,j]
        }
        vet  <- exp(vet)
      }else{
        vet <- 1
      }
      if(c[i] == 1){
        res2[g[i]]  <-  res2[g[i]]+log(dutT[nt1[i],stra[i]]*vet)
      }
#      print(paste(i,c[i],res2[g[i]],dutT[nt1[i],stra[i]],vet))
 #     break
      if(abs(res2[g[i]]) >= 1e+30){
        funcpassplines <- -1e+9
#goto 123
        break
      }

      res1[g[i]]  <-  res1[g[i]] + utT[nt1[i]+1,stra[i]]*vet 

      if(abs(res1[g[i]]) >= 1e+30){
        funcpassplines <- -1e+9
#goto 123
        break
      }

#! modification pour nouvelle vraisemblance / troncature:
      res3[g[i]]  <-  res3[g[i]] + utT[nt0[i]+1,stra[i]]*vet

      if(abs(res3[g[i]]) >= 1e+30){
        funcpassplines <- -1e+9
#goto 123
        break
      }
    }
    res  <-  0
    cptg  <-  0
    if(funcpassplines != -1e+9){
      

      for(k in 1:ng){
        sum <- 0
        if(cpt[k] > 0){
          nb  <-  nig[k]
    
          if(nb > 1){
            for(l in 1:nb){
              sum <- sum+log(1+theta*(nb-l))
            }
          }
        
          if(theta > 1e-5){
            if(AG == 1){
              res <-  res-(inv+nb)*log(theta*(res1[k]-res3[k])+1)+ res2[k] + sum
            }else{
              res  <-  res-(inv+nb)*log(theta*res1[k]+1)+(inv)*log(theta*res3[k]+1)+ res2[k] + sum
            }
            
            if(abs(res) >= 1e+30){
              funcpassplines <- -1e+9
#goto 123
              break
            }
          }else{
            if(AG == 1){
              res  <-  res-nb*log(theta*(res1[k]-res3[k])+1) 
                      -(res1[k]-res3[k])*(1-theta*(res1[k]-res3[k])/2
                        +theta*theta*(res1[k]-res3[k])*(res1[k]-res3[k])/3)+res2[k]+sum
            }else{
              res  <-  res-nb*log(theta*res1[k]+1)-res1[k]*(1-theta*res1[k]
                      /2+theta*theta*res1[k]*res1[k]/3)+res2[k]+sum+res3[k]*(1-theta*res3[k]/2 
                      +theta*theta*res3[k]*res3[k]/3)
            }
            if(abs(res) >= 1e+30){
              funcpassplines <- -1e+9
#goto 123
              break
            }
          }
        }
      }
    }#fin boucle effet <- 0
  }

#!--------- calcul de la penalisation -------------------
  if(funcpassplines != -1e+9){ 
  
    peT=0
    pe=0
    for(jj in 1:nst){#} !en plus strates A.Lafourcade 05/2014
      for(i in 1:(n-3)){
   
        peT[jj]  <-  peT[jj]+(theT[i,jj]*theT[i,jj]*m3m3[i])+
                    (theT[i+1,jj]*theT[i+1,jj]*m2m2[i])+
                    (theT[i+2,jj]*theT[i+2,jj]*m1m1[i])+
                    (theT[i+3,jj]*theT[i+3,jj]*mmm[i])+
                    (2*theT[i,jj]*theT[i+1,jj]* m3m2[i])+
                    (2*theT[i,jj]*theT[i+2,jj]*m3m1[i])+
                    (2*theT[i,jj]*theT[i+3,jj]*m3m[i])+
                    (2*theT[i+1,jj]*theT[i+2,jj]*m2m1[i])+
                    (2*theT[i+1,jj]*theT[i+3,jj]*m2m[i])+
                    (2*theT[i+2,jj] *theT[i+3,jj]*m1m[i])
      }
    } 
    for(jj in 1:nst){# !en plus strates A.Lafourcade 05/2014
      pe <- pe+peT[jj]*k0T[jj]
    }
    resnonpen  <-  res
    res  <-  res - pe
 
    if(abs(res) >= 1e+30){
      funcpassplines <- -1e+9
#goto 123
    }else{
      funcpassplines  <-  res
     # for(k in 1:ng){
     #   if(AG == 1){
     #     cumulhaz[k] <- res1[k]-res3[k]
     #   }else{ 
     #     cumulhaz[k] <- res1[k]
     #   }
     # }
    }

  }

  funcpassplines_list <- list(funcpassplines, pe, resnonpen)
  funcpassplines_list
}
