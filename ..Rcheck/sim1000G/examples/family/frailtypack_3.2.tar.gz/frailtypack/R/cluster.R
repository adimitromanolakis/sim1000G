"cluster" <- function(x)
 {
	x
 }